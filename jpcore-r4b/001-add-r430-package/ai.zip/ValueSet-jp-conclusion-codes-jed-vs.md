# JP Core DiagnosticReport Endoscopy Conclusion Codes JED ValueSet - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core DiagnosticReport Endoscopy Conclusion Codes JED ValueSet**

## ValueSet: JP Core DiagnosticReport Endoscopy Conclusion Codes JED ValueSet 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/ValueSet/JP_ConclusionCodesJed_VS
* **項目**: *Version*
  * **内容**: 2.0.0-dev
* **項目**: *Name*
  * **内容**: JP_ConclusionCodesJed_VS
* **項目**: *Title*
  * **内容**: JP Core DiagnosticReport Endoscopy Conclusion Codes JED ValueSet
* **項目**: *Status*
  * **内容**: Active ( 2023-10-31 )
* **項目**: *Copyright*
  * **内容**: Copyright JED-Project 一般社団法人 日本消化器内視鏡学会

 
日本消化器内視鏡学会が推進するJED (Japan Endoscopy Database) Projectのコード値セットのうち主に「質的診断」に該当するコード 

 **References** 

* [JP Core DiagnosticReport Endoscopy Profile](StructureDefinition-jp-diagnosticreport-endoscopy.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4B/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "jp-conclusion-codes-jed-vs",
  "url" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ConclusionCodesJed_VS",
  "version" : "2.0.0-dev",
  "name" : "JP_ConclusionCodesJed_VS",
  "title" : "JP Core DiagnosticReport Endoscopy Conclusion Codes JED ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-10-31",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "日本消化器内視鏡学会が推進するJED (Japan Endoscopy Database) Projectのコード値セットのうち主に「質的診断」に該当するコード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright JED-Project 一般社団法人 日本消化器内視鏡学会",
  "compose" : {
    "include" : [
      {
        "system" : "urn:oid:1.2.392.200270.4.1000.1",
        "concept" : [
          {
            "code" : "Z2Z30001",
            "display" : "異常なし"
          },
          {
            "code" : "Z2Z30101",
            "display" : "[化学放射線療法後] CR"
          },
          {
            "code" : "Z2Z30102",
            "display" : "[化学放射線療法後] nonCR/nonPD 縮小"
          },
          {
            "code" : "Z2Z30103",
            "display" : "[化学放射線療法後] nonCR/nonPD 不変"
          },
          {
            "code" : "Z2Z30104",
            "display" : "[化学放射線療法後] nonCR/nonPD 増大"
          },
          {
            "code" : "Z2Z30105",
            "display" : "[化学放射線療法後] PD"
          },
          {
            "code" : "Z2Z30106",
            "display" : "[化学放射線療法後] 遺残再発"
          },
          {
            "code" : "Z2Z30201",
            "display" : "[放射線療法後] CR"
          },
          {
            "code" : "Z2Z30202",
            "display" : "[放射線療法後] nonCR/nonPD 縮小"
          },
          {
            "code" : "Z2Z30203",
            "display" : "[放射線療法後] nonCR/nonPD 不変"
          },
          {
            "code" : "Z2Z30204",
            "display" : "[放射線療法後] nonCR/nonPD 増大"
          },
          {
            "code" : "Z2Z30205",
            "display" : "[放射線療法後] PD"
          },
          {
            "code" : "Z2Z30206",
            "display" : "[放射線療法後] 遺残再発"
          },
          {
            "code" : "Z2Z30301",
            "display" : "[化学療法後] CR"
          },
          {
            "code" : "Z2Z30302",
            "display" : "[化学療法後] nonCR/nonPD 縮小"
          },
          {
            "code" : "Z2Z30303",
            "display" : "[化学療法後] nonCR/nonPD 不変"
          },
          {
            "code" : "Z2Z30304",
            "display" : "[化学療法後] nonCR/nonPD 増大"
          },
          {
            "code" : "Z2Z30305",
            "display" : "[化学療法後] PD"
          },
          {
            "code" : "Z2Z30306",
            "display" : "[化学療法後] 遺残再発"
          },
          {
            "code" : "Z2Z30401",
            "display" : "[ESD後] 出血あり"
          },
          {
            "code" : "Z2Z30402",
            "display" : "[ESD後] 穿孔あり"
          },
          {
            "code" : "Z2Z30403",
            "display" : "[ESD後] 狭窄あり"
          },
          {
            "code" : "Z2Z30404",
            "display" : "[ESD後] 再発あり"
          },
          {
            "code" : "Z2Z30405",
            "display" : "[ESD後] 潰瘍あり"
          },
          {
            "code" : "Z2Z30406",
            "display" : "[ESD後] 瘢痕あり"
          },
          {
            "code" : "Z2Z30407",
            "display" : "[ESD後] 喉頭浮腫"
          },
          {
            "code" : "Z2Z30501",
            "display" : "[EMR後] 出血あり"
          },
          {
            "code" : "Z2Z30502",
            "display" : "[EMR後] 穿孔あり"
          },
          {
            "code" : "Z2Z30503",
            "display" : "[EMR後] 狭窄あり"
          },
          {
            "code" : "Z2Z30504",
            "display" : "[EMR後] 再発あり"
          },
          {
            "code" : "Z2Z30505",
            "display" : "[EMR後] 潰瘍あり"
          },
          {
            "code" : "Z2Z30506",
            "display" : "[EMR後] 瘢痕あり"
          },
          {
            "code" : "Z2Z30507",
            "display" : "[EMR後] 喉頭浮腫"
          },
          {
            "code" : "Z2Z30601",
            "display" : "[APC後] 出血あり"
          },
          {
            "code" : "Z2Z30602",
            "display" : "[APC後] 穿孔あり"
          },
          {
            "code" : "Z2Z30603",
            "display" : "[APC後] 狭窄あり"
          },
          {
            "code" : "Z2Z30604",
            "display" : "[APC後] 再発あり"
          },
          {
            "code" : "Z2Z30605",
            "display" : "[APC後] 潰瘍あり"
          },
          {
            "code" : "Z2Z30606",
            "display" : "[APC後] 瘢痕あり"
          },
          {
            "code" : "Z2Z30607",
            "display" : "[APC後] 喉頭浮腫"
          },
          {
            "code" : "Z2Z30701",
            "display" : "[ポリペクトミー後] 出血あり"
          },
          {
            "code" : "Z2Z30702",
            "display" : "[ポリペクトミー後] 穿孔あり"
          },
          {
            "code" : "Z2Z30703",
            "display" : "[ポリペクトミー後] 狭窄あり"
          },
          {
            "code" : "Z2Z30704",
            "display" : "[ポリペクトミー後] 再発あり"
          },
          {
            "code" : "Z2Z30705",
            "display" : "[ポリペクトミー後] 潰瘍あり"
          },
          {
            "code" : "Z2Z30706",
            "display" : "[ポリペクトミー後] 瘢痕あり"
          },
          {
            "code" : "Z2Z30801",
            "display" : "[腫瘍焼灼術後] 出血あり"
          },
          {
            "code" : "Z2Z30802",
            "display" : "[腫瘍焼灼術後] 穿孔あり"
          },
          {
            "code" : "Z2Z30803",
            "display" : "[腫瘍焼灼術後] 狭窄あり"
          },
          {
            "code" : "Z2Z30804",
            "display" : "[腫瘍焼灼術後] 再発あり"
          },
          {
            "code" : "Z2Z30805",
            "display" : "[腫瘍焼灼術後] 潰瘍あり"
          },
          {
            "code" : "Z2Z30806",
            "display" : "[腫瘍焼灼術後] 瘢痕あり"
          },
          {
            "code" : "Z2A30200",
            "display" : "頭頸部癌"
          },
          {
            "code" : "Z2A30300",
            "display" : "壁内転移"
          },
          {
            "code" : "Z2A30400",
            "display" : "悪性黒色腫"
          },
          {
            "code" : "Z2A30500",
            "display" : "乳頭腫"
          },
          {
            "code" : "Z2A30601",
            "display" : "[粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2A30602",
            "display" : "[粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2A30603",
            "display" : "[粘膜下腫瘍] 嚢腫"
          },
          {
            "code" : "Z2A30604",
            "display" : "[粘膜下腫瘍] リンパ管腫"
          },
          {
            "code" : "Z2A30605",
            "display" : "[粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2A30606",
            "display" : "[粘膜下腫瘍] 血管腫"
          },
          {
            "code" : "Z2A30607",
            "display" : "[粘膜下腫瘍] 顆粒細胞腫"
          },
          {
            "code" : "Z2A306ZZ",
            "display" : "[粘膜下腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2A30700",
            "display" : "悪性リンパ腫"
          },
          {
            "code" : "Z2A30800",
            "display" : "転移性腫瘍"
          },
          {
            "code" : "Z2A30900",
            "display" : "他臓器癌咽喉頭浸潤"
          },
          {
            "code" : "Z2A31000",
            "display" : "肉芽腫"
          },
          {
            "code" : "Z2A31100",
            "display" : "嚢胞"
          },
          {
            "code" : "Z2A31200",
            "display" : "メラノーシス"
          },
          {
            "code" : "Z2A31300",
            "display" : "錯角化"
          },
          {
            "code" : "Z2A31400",
            "display" : "炎症"
          },
          {
            "code" : "Z2A31500",
            "display" : "リンパ濾胞"
          },
          {
            "code" : "Z2A31600",
            "display" : "良性潰瘍"
          },
          {
            "code" : "Z2A31700",
            "display" : "毛細血管拡張症"
          },
          {
            "code" : "Z2A31801",
            "display" : "[カンジダ症] 軽度"
          },
          {
            "code" : "Z2A31802",
            "display" : "[カンジダ症] 中等度"
          },
          {
            "code" : "Z2A31803",
            "display" : "[カンジダ症] 高度"
          },
          {
            "code" : "Z2A31900",
            "display" : "廔孔"
          },
          {
            "code" : "Z2A32000",
            "display" : "異物"
          },
          {
            "code" : "Z2A32100",
            "display" : "裂傷"
          },
          {
            "code" : "Z2A32200",
            "display" : "壁外性圧排"
          },
          {
            "code" : "Z2A32301",
            "display" : "[経過観察後] 縮小"
          },
          {
            "code" : "Z2A32302",
            "display" : "[経過観察後] 不変"
          },
          {
            "code" : "Z2A32303",
            "display" : "[経過観察後] 増大"
          },
          {
            "code" : "Z2A32401",
            "display" : "[ELPS後] 出血あり"
          },
          {
            "code" : "Z2A32402",
            "display" : "[ELPS後] 穿孔あり"
          },
          {
            "code" : "Z2A32403",
            "display" : "[ELPS後] 狭窄あり"
          },
          {
            "code" : "Z2A32404",
            "display" : "[ELPS後] 再発あり"
          },
          {
            "code" : "Z2A32405",
            "display" : "[ELPS後] 潰瘍あり"
          },
          {
            "code" : "Z2A32406",
            "display" : "[ELPS後] 瘢痕あり"
          },
          {
            "code" : "Z2A32407",
            "display" : "[ELPS後] 喉頭浮腫"
          },
          {
            "code" : "Z2A32500",
            "display" : "術後吻合部狭窄"
          },
          {
            "code" : "Z2A32600",
            "display" : "術後縫合不全"
          },
          {
            "code" : "Z2A32700",
            "display" : "経口的治療後狭窄"
          },
          {
            "code" : "Z2A32801",
            "display" : "[咽喉食摘術後] 空腸再建"
          },
          {
            "code" : "Z2A32802",
            "display" : "[咽喉食摘術後] 胃管再建"
          },
          {
            "code" : "Z2A32900",
            "display" : "喉頭全摘術後"
          },
          {
            "code" : "Z2A33000",
            "display" : "咽頭部分切除術後"
          },
          {
            "code" : "Z2A33100",
            "display" : "喉頭部分切除術後"
          },
          {
            "code" : "Z2A30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2B30200",
            "display" : "食道癌"
          },
          {
            "code" : "Z2B30300",
            "display" : "バレット食道腺癌"
          },
          {
            "code" : "Z2B30400",
            "display" : "食道胃接合部腺癌"
          },
          {
            "code" : "Z2B30500",
            "display" : "食道悪性黒色腫"
          },
          {
            "code" : "Z2B30600",
            "display" : "低異型度上皮内腫瘍"
          },
          {
            "code" : "Z2B30700",
            "display" : "ヨード淡染帯"
          },
          {
            "code" : "Z2B30801",
            "display" : "[ヨード不染帯] Grade A（ヨード不染色無し）"
          },
          {
            "code" : "Z2B30802",
            "display" : "[ヨード不染帯] Grade B（A、C以外）"
          },
          {
            "code" : "Z2B30803",
            "display" : "[ヨード不染帯] Grade C"
          },
          {
            "code" : "Z2B308ZZ",
            "display" : "[ヨード不染帯] その他（記述する）"
          },
          {
            "code" : "Z2B30900",
            "display" : "食道癌壁内転移"
          },
          {
            "code" : "Z2B31000",
            "display" : "食道乳頭腫"
          },
          {
            "code" : "Z2B31101",
            "display" : "[食道粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2B31102",
            "display" : "[食道粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2B31103",
            "display" : "[食道粘膜下腫瘍] 嚢胞"
          },
          {
            "code" : "Z2B31104",
            "display" : "[食道粘膜下腫瘍] リンパ管腫"
          },
          {
            "code" : "Z2B31105",
            "display" : "[食道粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2B31106",
            "display" : "[食道粘膜下腫瘍] 血管腫"
          },
          {
            "code" : "Z2B31107",
            "display" : "[食道粘膜下腫瘍] 顆粒細胞腫"
          },
          {
            "code" : "Z2B311ZZ",
            "display" : "[食道粘膜下腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2B31200",
            "display" : "食道悪性リンパ腫"
          },
          {
            "code" : "Z2B31300",
            "display" : "転移性食道腫瘍"
          },
          {
            "code" : "Z2B31400",
            "display" : "他臓器癌食道浸潤"
          },
          {
            "code" : "Z2B31501",
            "display" : "[逆流性食道炎] Grade N"
          },
          {
            "code" : "Z2B31502",
            "display" : "[逆流性食道炎] Grade M"
          },
          {
            "code" : "Z2B31503",
            "display" : "[逆流性食道炎] Grade A"
          },
          {
            "code" : "Z2B31504",
            "display" : "[逆流性食道炎] Grade B"
          },
          {
            "code" : "Z2B31505",
            "display" : "[逆流性食道炎] Grade C"
          },
          {
            "code" : "Z2B31506",
            "display" : "[逆流性食道炎] Grade D"
          },
          {
            "code" : "Z2B31601",
            "display" : "[食道カンジダ症] 軽度"
          },
          {
            "code" : "Z2B31602",
            "display" : "[食道カンジダ症] 中等度"
          },
          {
            "code" : "Z2B31603",
            "display" : "[食道カンジダ症] 高度"
          },
          {
            "code" : "Z2B31700",
            "display" : "好酸球性食道炎"
          },
          {
            "code" : "Z2B31800",
            "display" : "腐食性食道炎"
          },
          {
            "code" : "Z2B31900",
            "display" : "結核性食道炎"
          },
          {
            "code" : "Z2B32000",
            "display" : "薬剤性食道炎"
          },
          {
            "code" : "Z2B32102",
            "display" : "[食道裂孔ヘルニア] 傍食道型"
          },
          {
            "code" : "Z2B32103",
            "display" : "[食道裂孔ヘルニア] 混合型"
          },
          {
            "code" : "Z2B32104",
            "display" : "[食道裂孔ヘルニア] 滑脱型"
          },
          {
            "code" : "Z2B32200",
            "display" : "食道静脈瘤"
          },
          {
            "code" : "Z2B32301",
            "display" : "[バレット食道] SSBE"
          },
          {
            "code" : "Z2B32302",
            "display" : "[バレット食道] LSBE"
          },
          {
            "code" : "Z2B32400",
            "display" : "食道アカラシア"
          },
          {
            "code" : "Z2B32500",
            "display" : "マロリーワイス症候群"
          },
          {
            "code" : "Z2B32600",
            "display" : "良性食道潰瘍"
          },
          {
            "code" : "Z2B32700",
            "display" : "毛細血管拡張症"
          },
          {
            "code" : "Z2B32800",
            "display" : "食道憩室"
          },
          {
            "code" : "Z2B32900",
            "display" : "良性食道狭窄"
          },
          {
            "code" : "Z2B33000",
            "display" : "食道ウエブ"
          },
          {
            "code" : "Z2B33100",
            "display" : "術後吻合部狭窄"
          },
          {
            "code" : "Z2B33200",
            "display" : "内視鏡治療後狭窄"
          },
          {
            "code" : "Z2B33300",
            "display" : "孤立性静脈拡張"
          },
          {
            "code" : "Z2B33400",
            "display" : "術後縫合不全"
          },
          {
            "code" : "Z2B33500",
            "display" : "食道廔孔"
          },
          {
            "code" : "Z2B33600",
            "display" : "食道異物"
          },
          {
            "code" : "Z2B33700",
            "display" : "食道裂傷"
          },
          {
            "code" : "Z2B33800",
            "display" : "食道穿孔"
          },
          {
            "code" : "Z2B33900",
            "display" : "異所性胃粘膜"
          },
          {
            "code" : "Z2B34000",
            "display" : "壁外性圧排"
          },
          {
            "code" : "Z2B34100",
            "display" : "食道ポリープ"
          },
          {
            "code" : "Z2B34200",
            "display" : "食道メラノーシス"
          },
          {
            "code" : "Z2B34300",
            "display" : "グリコーゲン・アカントーシス"
          },
          {
            "code" : "Z2B34400",
            "display" : "経過観察後（記述する）"
          },
          {
            "code" : "Z2B34600",
            "display" : "POEM後（記述する）"
          },
          {
            "code" : "Z2B34501",
            "display" : "[PDT後] 出血あり"
          },
          {
            "code" : "Z2B34502",
            "display" : "[PDT後] 穿孔あり"
          },
          {
            "code" : "Z2B34503",
            "display" : "[PDT後] 狭窄あり"
          },
          {
            "code" : "Z2B34504",
            "display" : "[PDT後] 再発あり"
          },
          {
            "code" : "Z2B34505",
            "display" : "[PDT後] 潰瘍あり"
          },
          {
            "code" : "Z2B34506",
            "display" : "[PDT後] 瘢痕あり"
          },
          {
            "code" : "Z2B34701",
            "display" : "[EVL後] 出血あり"
          },
          {
            "code" : "Z2B34702",
            "display" : "[EVL後] 穿孔あり"
          },
          {
            "code" : "Z2B34703",
            "display" : "[EVL後] 狭窄あり"
          },
          {
            "code" : "Z2B34704",
            "display" : "[EVL後] 再発あり"
          },
          {
            "code" : "Z2B34705",
            "display" : "[EVL後] 潰瘍あり"
          },
          {
            "code" : "Z2B34706",
            "display" : "[EVL後] 瘢痕あり"
          },
          {
            "code" : "Z2B34801",
            "display" : "[EIS後] 出血あり"
          },
          {
            "code" : "Z2B34802",
            "display" : "[EIS後] 穿孔あり"
          },
          {
            "code" : "Z2B34803",
            "display" : "[EIS後] 狭窄あり"
          },
          {
            "code" : "Z2B34804",
            "display" : "[EIS後] 再発あり"
          },
          {
            "code" : "Z2B34805",
            "display" : "[EIS後] 潰瘍あり"
          },
          {
            "code" : "Z2B34806",
            "display" : "[EIS後] 瘢痕あり"
          },
          {
            "code" : "Z2B34901",
            "display" : "[食道亜全摘後] 胃管再建"
          },
          {
            "code" : "Z2B34902",
            "display" : "[食道亜全摘後] 結腸再建"
          },
          {
            "code" : "Z2B34903",
            "display" : "[食道亜全摘後] 空腸再建"
          },
          {
            "code" : "Z2B35000",
            "display" : "咽喉食摘後"
          },
          {
            "code" : "Z2B35100",
            "display" : "アカラシア術後"
          },
          {
            "code" : "Z2B30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2C30200",
            "display" : "腺腫"
          },
          {
            "code" : "Z2C30300",
            "display" : "胃癌"
          },
          {
            "code" : "Z2C30401",
            "display" : "[胃粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2C30402",
            "display" : "[胃粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2C30403",
            "display" : "[胃粘膜下腫瘍] 異所性膵組織"
          },
          {
            "code" : "Z2C30404",
            "display" : "[胃粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2C304ZZ",
            "display" : "[胃粘膜下腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2C30501",
            "display" : "[胃悪性リンパ腫] DLBCL"
          },
          {
            "code" : "Z2C30502",
            "display" : "[胃悪性リンパ腫] MALTリンパ腫"
          },
          {
            "code" : "Z2C305ZZ",
            "display" : "[胃悪性リンパ腫] その他（記述する）"
          },
          {
            "code" : "Z2C30600",
            "display" : "胃NET"
          },
          {
            "code" : "Z2C30700",
            "display" : "他臓器癌胃転移"
          },
          {
            "code" : "Z2C30800",
            "display" : "他臓器癌胃浸潤"
          },
          {
            "code" : "Z2C30900",
            "display" : "萎縮性胃炎"
          },
          {
            "code" : "Z2C31000",
            "display" : "表層性胃炎"
          },
          {
            "code" : "Z2C31100",
            "display" : "出血性胃炎"
          },
          {
            "code" : "Z2C31200",
            "display" : "びらん性胃炎"
          },
          {
            "code" : "Z2C31300",
            "display" : "疣状胃炎"
          },
          {
            "code" : "Z2C31400",
            "display" : "肥厚性胃炎"
          },
          {
            "code" : "Z2C31500",
            "display" : "急性胃粘膜病変(AGML)"
          },
          {
            "code" : "Z2C31600",
            "display" : "自己免疫性胃炎"
          },
          {
            "code" : "Z2C31700",
            "display" : "鳥肌胃炎"
          },
          {
            "code" : "Z2C31800",
            "display" : "好酸球性胃炎"
          },
          {
            "code" : "Z2C31900",
            "display" : "残胃炎"
          },
          {
            "code" : "Z2C32000",
            "display" : "その他の胃炎（記述する）"
          },
          {
            "code" : "Z2C32100",
            "display" : "腸上皮化生"
          },
          {
            "code" : "Z2C32201",
            "display" : "[胃潰瘍] A1stage"
          },
          {
            "code" : "Z2C32202",
            "display" : "[胃潰瘍] A2stage"
          },
          {
            "code" : "Z2C32211",
            "display" : "[胃潰瘍] H1stage"
          },
          {
            "code" : "Z2C32212",
            "display" : "[胃潰瘍] H2stage"
          },
          {
            "code" : "Z2C32221",
            "display" : "[胃潰瘍] S1stage"
          },
          {
            "code" : "Z2C32222",
            "display" : "[胃潰瘍] S2stage"
          },
          {
            "code" : "Z2C32301",
            "display" : "[ポリープ] 過形成性ポリープ"
          },
          {
            "code" : "Z2C32302",
            "display" : "[ポリープ] 胃底腺ポリープ"
          },
          {
            "code" : "Z2C32303",
            "display" : "[ポリープ] ポリポージス"
          },
          {
            "code" : "Z2C323ZZ",
            "display" : "[ポリープ] その他（記述する）"
          },
          {
            "code" : "Z2C32400",
            "display" : "胃憩室"
          },
          {
            "code" : "Z2C32501",
            "display" : "[異物] アニサキス症"
          },
          {
            "code" : "Z2C32502",
            "display" : "[異物] 胃石"
          },
          {
            "code" : "Z2C32503",
            "display" : "[異物] 義歯"
          },
          {
            "code" : "Z2C325ZZ",
            "display" : "[異物] その他（記述する）"
          },
          {
            "code" : "Z2C32600",
            "display" : "日の丸紅斑、血管拡張症"
          },
          {
            "code" : "Z2C32700",
            "display" : "胃前庭部毛細血管拡張症（DAVE, GAVE）"
          },
          {
            "code" : "Z2C32800",
            "display" : "門脈圧亢進性胃症"
          },
          {
            "code" : "Z2C32900",
            "display" : "胃静脈瘤"
          },
          {
            "code" : "Z2C33000",
            "display" : "マロリーワイス症候群"
          },
          {
            "code" : "Z2C33100",
            "display" : "PEG後"
          },
          {
            "code" : "Z2C33200",
            "display" : "その他の内視鏡治療後（記述する）"
          },
          {
            "code" : "Z2C33300",
            "display" : "HP除菌後"
          },
          {
            "code" : "Z2C33400",
            "display" : "その他治療後"
          },
          {
            "code" : "Z2C33500",
            "display" : "PPG後"
          },
          {
            "code" : "Z2C33600",
            "display" : "DG(Roux-Y)後"
          },
          {
            "code" : "Z2C33700",
            "display" : "DG(B-I)後"
          },
          {
            "code" : "Z2C33800",
            "display" : "DG(B-II)後"
          },
          {
            "code" : "Z2C33900",
            "display" : "噴門側胃切除後"
          },
          {
            "code" : "Z2C34000",
            "display" : "胃全摘後"
          },
          {
            "code" : "Z2C34100",
            "display" : "胃管"
          },
          {
            "code" : "Z2C34200",
            "display" : "消化管バイパス術後"
          },
          {
            "code" : "Z2C34300",
            "display" : "胃局所切除後"
          },
          {
            "code" : "Z2C34400",
            "display" : "PD後"
          },
          {
            "code" : "Z2C34500",
            "display" : "PPPD後"
          },
          {
            "code" : "Z2C30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2D30200",
            "display" : "十二指腸腺腫"
          },
          {
            "code" : "Z2D30300",
            "display" : "十二指腸癌"
          },
          {
            "code" : "Z2D30401",
            "display" : "[十二指腸粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2D30402",
            "display" : "[十二指腸粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2D30403",
            "display" : "[十二指腸粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2D304ZZ",
            "display" : "[十二指腸粘膜下腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2D30501",
            "display" : "[十二指腸悪性リンパ腫] DLBCL"
          },
          {
            "code" : "Z2D30502",
            "display" : "[十二指腸悪性リンパ腫] 濾胞性リンパ腫"
          },
          {
            "code" : "Z2D30503",
            "display" : "[十二指腸悪性リンパ腫] MALTリンパ腫"
          },
          {
            "code" : "Z2D305ZZ",
            "display" : "[十二指腸悪性リンパ腫] その他（記述する）"
          },
          {
            "code" : "Z2D30600",
            "display" : "十二指腸NET"
          },
          {
            "code" : "Z2D30700",
            "display" : "他臓器癌十二指腸転移"
          },
          {
            "code" : "Z2D30800",
            "display" : "他臓器癌十二指腸浸潤"
          },
          {
            "code" : "Z2D30900",
            "display" : "十二指腸炎"
          },
          {
            "code" : "Z2D31001",
            "display" : "[十二指腸潰瘍] A1stage"
          },
          {
            "code" : "Z2D31002",
            "display" : "[十二指腸潰瘍] A2stage"
          },
          {
            "code" : "Z2D31011",
            "display" : "[十二指腸潰瘍] H1stage"
          },
          {
            "code" : "Z2D31012",
            "display" : "[十二指腸潰瘍] H2stage"
          },
          {
            "code" : "Z2D31021",
            "display" : "[十二指腸潰瘍] S1stage"
          },
          {
            "code" : "Z2D31022",
            "display" : "[十二指腸潰瘍] S2stage"
          },
          {
            "code" : "Z2D31100",
            "display" : "異所性胃粘膜"
          },
          {
            "code" : "Z2D31200",
            "display" : "胃上皮化生"
          },
          {
            "code" : "Z2D31300",
            "display" : "ブルンネル腺過形成"
          },
          {
            "code" : "Z2D31400",
            "display" : "憩室"
          },
          {
            "code" : "Z2D31500",
            "display" : "異物"
          },
          {
            "code" : "Z2D31600",
            "display" : "血管拡張症"
          },
          {
            "code" : "Z2D31700",
            "display" : "十二指腸静脈瘤"
          },
          {
            "code" : "Z2D31801",
            "display" : "[その他の内視鏡治療後] 出血あり"
          },
          {
            "code" : "Z2D31802",
            "display" : "[その他の内視鏡治療後] 穿孔あり"
          },
          {
            "code" : "Z2D31803",
            "display" : "[その他の内視鏡治療後] 狭窄あり"
          },
          {
            "code" : "Z2D31804",
            "display" : "[その他の内視鏡治療後] 再発あり"
          },
          {
            "code" : "Z2D31805",
            "display" : "[その他の内視鏡治療後] 潰瘍あり"
          },
          {
            "code" : "Z2D31806",
            "display" : "[その他の内視鏡治療後] 瘢痕あり"
          },
          {
            "code" : "Z2D31900",
            "display" : "十二指腸術後"
          },
          {
            "code" : "Z2D30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2F30200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2F30301",
            "display" : "[造影出来ず] カニュレーション出来ず"
          },
          {
            "code" : "Z2F30302",
            "display" : "[造影出来ず] 到達出来ず"
          },
          {
            "code" : "Z2F303ZZ",
            "display" : "[造影出来ず] その他（記述する）"
          },
          {
            "code" : "Z2F30400",
            "display" : "乳頭部腺腫"
          },
          {
            "code" : "Z2F30500",
            "display" : "乳頭部癌"
          },
          {
            "code" : "Z2F30600",
            "display" : "乳頭部腫瘍"
          },
          {
            "code" : "Z2F30701",
            "display" : "[乳頭開大〔Fish mouth〕] IPMNによる"
          },
          {
            "code" : "Z2F30702",
            "display" : "[乳頭開大〔Fish mouth〕] IPNBによる"
          },
          {
            "code" : "Z2F30801",
            "display" : "[乳頭術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2F30802",
            "display" : "[乳頭術後] 乳頭形成術後"
          },
          {
            "code" : "Z2F30900",
            "display" : "結石嵌頓"
          },
          {
            "code" : "Z2F31000",
            "display" : "良性乳頭狭窄"
          },
          {
            "code" : "Z2F31100",
            "display" : "乳頭炎"
          },
          {
            "code" : "Z2F31201",
            "display" : "[内視鏡治療後] 切開(EST)"
          },
          {
            "code" : "Z2F31202",
            "display" : "[内視鏡治療後] 拡張(EPBD)"
          },
          {
            "code" : "Z2F31203",
            "display" : "[内視鏡治療後] 切除(Papillectomy)"
          },
          {
            "code" : "Z2F31204",
            "display" : "[内視鏡治療後] 焼灼(APC)"
          },
          {
            "code" : "Z2F31205",
            "display" : "[内視鏡治療後] ステント"
          },
          {
            "code" : "Z2F31301",
            "display" : "[腫脹] 胆管胆石排出後"
          },
          {
            "code" : "Z2F31400",
            "display" : "乳頭開大"
          },
          {
            "code" : "Z2F31500",
            "display" : "ステント"
          },
          {
            "code" : "Z2F30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2G30200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2G30300",
            "display" : "副乳頭部腺腫"
          },
          {
            "code" : "Z2G30400",
            "display" : "副乳頭部癌"
          },
          {
            "code" : "Z2G30500",
            "display" : "副乳頭部腫瘍"
          },
          {
            "code" : "Z2G30600",
            "display" : "副乳頭開大〔Fish mouth〕"
          },
          {
            "code" : "Z2G30701",
            "display" : "[副乳頭術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2G30800",
            "display" : "結石嵌頓"
          },
          {
            "code" : "Z2G30900",
            "display" : "良性副乳頭狭窄"
          },
          {
            "code" : "Z2G31000",
            "display" : "副乳頭炎"
          },
          {
            "code" : "Z2G31101",
            "display" : "[内視鏡治療後] 切開(EST)"
          },
          {
            "code" : "Z2G31102",
            "display" : "[内視鏡治療後] 拡張(EPBD)"
          },
          {
            "code" : "Z2G31103",
            "display" : "[内視鏡治療後] 切除(Papillectomy)"
          },
          {
            "code" : "Z2G31104",
            "display" : "[内視鏡治療後] 焼灼(APC)"
          },
          {
            "code" : "Z2G31200",
            "display" : "腫脹"
          },
          {
            "code" : "Z2G31300",
            "display" : "副乳頭開大"
          },
          {
            "code" : "Z2G30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2H30200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2H30300",
            "display" : "腫瘍性疾患"
          },
          {
            "code" : "Z2H30400",
            "display" : "早期胆嚢癌 M-MP癌"
          },
          {
            "code" : "Z2H30500",
            "display" : "進行胆嚢癌 SS癌"
          },
          {
            "code" : "Z2H30600",
            "display" : "進行胆嚢癌 SE癌"
          },
          {
            "code" : "Z2H30700",
            "display" : "進行胆嚢癌 SI癌"
          },
          {
            "code" : "Z2H30800",
            "display" : "コレステロールポリープ"
          },
          {
            "code" : "Z2H30900",
            "display" : "炎症性ポリープ"
          },
          {
            "code" : "Z2H31000",
            "display" : "線維性ポリープ"
          },
          {
            "code" : "Z2H31100",
            "display" : "肝外胆管癌"
          },
          {
            "code" : "Z2H31200",
            "display" : "肝門部胆管癌〔Klatskin腫瘍〕"
          },
          {
            "code" : "Z2H31300",
            "display" : "肝内胆管癌"
          },
          {
            "code" : "Z2H31400",
            "display" : "胆管乳頭腺腫症〔Biliary Papillomatosis〕"
          },
          {
            "code" : "Z2H31500",
            "display" : "胆管内乳頭粘液性腫瘍"
          },
          {
            "code" : "Z2H31600",
            "display" : "胆管嚢胞性腫瘍"
          },
          {
            "code" : "Z2H31700",
            "display" : "胆道腫瘍"
          },
          {
            "code" : "Z2H31801",
            "display" : "[悪性胆管狭窄] 膵癌による"
          },
          {
            "code" : "Z2H31802",
            "display" : "[悪性胆管狭窄] 胃癌による"
          },
          {
            "code" : "Z2H31803",
            "display" : "[悪性胆管狭窄] リンパ節による"
          },
          {
            "code" : "Z2H31901",
            "display" : "[胆道術後] 胆摘後"
          },
          {
            "code" : "Z2H31902",
            "display" : "[胆道術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2H31903",
            "display" : "[胆道術後] 膵体尾部切除術後"
          },
          {
            "code" : "Z2H31904",
            "display" : "[胆道術後] 肝右葉切除術後"
          },
          {
            "code" : "Z2H31905",
            "display" : "[胆道術後] 肝左葉切除術後"
          },
          {
            "code" : "Z2H31906",
            "display" : "[胆道術後] 胆管空腸吻合術後"
          },
          {
            "code" : "Z2H32000",
            "display" : "正常胆摘後胆道像"
          },
          {
            "code" : "Z2H32100",
            "display" : "正常乳頭切開後胆道像"
          },
          {
            "code" : "Z2H32200",
            "display" : "肝内結石"
          },
          {
            "code" : "Z2H32300",
            "display" : "総胆管結石"
          },
          {
            "code" : "Z2H32401",
            "display" : "[胆嚢結石] 胆嚢内結石"
          },
          {
            "code" : "Z2H32402",
            "display" : "[胆嚢結石] 胆嚢管結石"
          },
          {
            "code" : "Z2H32403",
            "display" : "[胆嚢結石] 遺残胆嚢管結石"
          },
          {
            "code" : "Z2H32500",
            "display" : "胆泥〔Debris〕"
          },
          {
            "code" : "Z2H32600",
            "display" : "Mirizzi症候群"
          },
          {
            "code" : "Z2H32701",
            "display" : "[胆嚢腺筋腫症] びまん型 Diffuse type"
          },
          {
            "code" : "Z2H32702",
            "display" : "[胆嚢腺筋腫症] 分節型 Segmental type"
          },
          {
            "code" : "Z2H32703",
            "display" : "[胆嚢腺筋腫症] 底部型 Fundal type"
          },
          {
            "code" : "Z2H32800",
            "display" : "胆嚢ポリープ"
          },
          {
            "code" : "Z2H32900",
            "display" : "良性胆管狭窄"
          },
          {
            "code" : "Z2H33000",
            "display" : "胆管閉塞"
          },
          {
            "code" : "Z2H33100",
            "display" : "胆管拡張"
          },
          {
            "code" : "Z2H33200",
            "display" : "胆汁漏出"
          },
          {
            "code" : "Z2H33300",
            "display" : "胆管瘻"
          },
          {
            "code" : "Z2H33400",
            "display" : "Sump症候群"
          },
          {
            "code" : "Z2H33501",
            "display" : "[膵胆管合流異常] 胆管合流型"
          },
          {
            "code" : "Z2H33502",
            "display" : "[膵胆管合流異常] 膵管合流型"
          },
          {
            "code" : "Z2H33601",
            "display" : "[総胆管嚢腫] Alonso-Lej I 型"
          },
          {
            "code" : "Z2H33602",
            "display" : "[総胆管嚢腫] Alonso-Lej II 型"
          },
          {
            "code" : "Z2H33611",
            "display" : "[総胆管嚢腫] 総胆管瘤 Alonso-Lej III 型"
          },
          {
            "code" : "Z2H33621",
            "display" : "[総胆管嚢腫] 戸谷 I 型"
          },
          {
            "code" : "Z2H33622",
            "display" : "[総胆管嚢腫] 戸谷 II 型"
          },
          {
            "code" : "Z2H33623",
            "display" : "[総胆管嚢腫] 戸谷 III 型"
          },
          {
            "code" : "Z2H33624",
            "display" : "[総胆管嚢腫] 戸谷 IV 型"
          },
          {
            "code" : "Z2H33700",
            "display" : "Caroli病"
          },
          {
            "code" : "Z2H33800",
            "display" : "硬化性胆管炎"
          },
          {
            "code" : "Z2H33900",
            "display" : "化膿性胆管炎"
          },
          {
            "code" : "Z2H34000",
            "display" : "肝硬変"
          },
          {
            "code" : "Z2H34100",
            "display" : "血液胆汁"
          },
          {
            "code" : "Z2H34200",
            "display" : "寄生虫"
          },
          {
            "code" : "Z2H30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2HC0200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2HC0300",
            "display" : "胆道病変描出出来ず"
          },
          {
            "code" : "Z2HC0401",
            "display" : "早期胆嚢癌 M-MP癌"
          },
          {
            "code" : "Z2HC0402",
            "display" : "進行胆嚢癌 SS癌"
          },
          {
            "code" : "Z2HC0403",
            "display" : "進行胆嚢癌 SE癌"
          },
          {
            "code" : "Z2HC0404",
            "display" : "進行胆嚢癌 SI癌"
          },
          {
            "code" : "Z2HC0500",
            "display" : "胆嚢腺腫"
          },
          {
            "code" : "Z2HC0601",
            "display" : "コレステロールポリープ"
          },
          {
            "code" : "Z2HC0602",
            "display" : "炎症性ポリープ"
          },
          {
            "code" : "Z2HC0603",
            "display" : "線維性ポリープ"
          },
          {
            "code" : "Z2HC0700",
            "display" : "肝外胆管癌"
          },
          {
            "code" : "Z2HC0800",
            "display" : "肝門部胆管癌〔Klatskin腫瘍〕"
          },
          {
            "code" : "Z2HC0900",
            "display" : "肝内胆管癌"
          },
          {
            "code" : "Z2HC1000",
            "display" : "胆管乳頭腺腫症〔Biliary Papillomatosis〕"
          },
          {
            "code" : "Z2HC1100",
            "display" : "胆管内乳頭粘液性腫瘍"
          },
          {
            "code" : "Z2HC1200",
            "display" : "胆管嚢胞性腫瘍"
          },
          {
            "code" : "Z2HC1301",
            "display" : "肝外胆管腫瘍"
          },
          {
            "code" : "Z2HC1302",
            "display" : "肝内胆管腫瘍"
          },
          {
            "code" : "Z2HC1401",
            "display" : "[悪性胆管狭窄] 膵癌による"
          },
          {
            "code" : "Z2HC1402",
            "display" : "[悪性胆管狭窄] 胃癌による"
          },
          {
            "code" : "Z2HC1403",
            "display" : "[悪性胆管狭窄] リンパ節による"
          },
          {
            "code" : "Z2HC1501",
            "display" : "[胆道術後] 胆摘後"
          },
          {
            "code" : "Z2HC1502",
            "display" : "[胆道術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2HC1503",
            "display" : "[胆道術後] 膵体尾部切除術後"
          },
          {
            "code" : "Z2HC1504",
            "display" : "[胆道術後] 肝右葉切除術後"
          },
          {
            "code" : "Z2HC1505",
            "display" : "[胆道術後] 肝左葉切除術後"
          },
          {
            "code" : "Z2HC1506",
            "display" : "[胆道術後] 胆管空腸吻合術後"
          },
          {
            "code" : "Z2HC1600",
            "display" : "肝内結石"
          },
          {
            "code" : "Z2HC1700",
            "display" : "総胆管結石"
          },
          {
            "code" : "Z2HC1801",
            "display" : "[胆嚢結石] 胆嚢内結石"
          },
          {
            "code" : "Z2HC1802",
            "display" : "[胆嚢結石] 胆嚢管結石"
          },
          {
            "code" : "Z2HC1803",
            "display" : "[胆嚢結石] 遺残胆嚢管結石"
          },
          {
            "code" : "Z2HC1900",
            "display" : "胆泥〔Debris〕"
          },
          {
            "code" : "Z2HC2000",
            "display" : "Mirizzi症候群"
          },
          {
            "code" : "Z2HC2101",
            "display" : "[胆嚢腺筋腫症] びまん型 Diffuse type"
          },
          {
            "code" : "Z2HC2102",
            "display" : "[胆嚢腺筋腫症] 分節型 Segmental type"
          },
          {
            "code" : "Z2HC2103",
            "display" : "[胆嚢腺筋腫症] 底部型 Fundal type"
          },
          {
            "code" : "Z2HC2200",
            "display" : "胆嚢ポリープ"
          },
          {
            "code" : "Z2HC2300",
            "display" : "良性胆管狭窄"
          },
          {
            "code" : "Z2HC2400",
            "display" : "胆管閉塞"
          },
          {
            "code" : "Z2HC2500",
            "display" : "胆管拡張"
          },
          {
            "code" : "Z2HC2600",
            "display" : "胆管瘻"
          },
          {
            "code" : "Z2HC2700",
            "display" : "Sump症候群"
          },
          {
            "code" : "Z2HC2801",
            "display" : "[膵胆管合流異常] 胆管合流型"
          },
          {
            "code" : "Z2HC2802",
            "display" : "[膵胆管合流異常] 膵管合流型"
          },
          {
            "code" : "Z2HC2901",
            "display" : "[総胆管嚢腫] Alonso-Lej I 型"
          },
          {
            "code" : "Z2HC2902",
            "display" : "[総胆管嚢腫] Alonso-Lej II 型"
          },
          {
            "code" : "Z2HC2911",
            "display" : "[総胆管嚢腫] 総胆管瘤 Alonso-Lej III 型"
          },
          {
            "code" : "Z2HC2921",
            "display" : "[総胆管嚢腫] 戸谷 I 型"
          },
          {
            "code" : "Z2HC2922",
            "display" : "[総胆管嚢腫] 戸谷 II 型"
          },
          {
            "code" : "Z2HC2923",
            "display" : "[総胆管嚢腫] 戸谷 III 型"
          },
          {
            "code" : "Z2HC2924",
            "display" : "[総胆管嚢腫] 戸谷 IV 型"
          },
          {
            "code" : "Z2HC3000",
            "display" : "Caroli病"
          },
          {
            "code" : "Z2HC3100",
            "display" : "硬化性胆管炎"
          },
          {
            "code" : "Z2HC3200",
            "display" : "化膿性胆管炎"
          },
          {
            "code" : "Z2HC3300",
            "display" : "寄生虫"
          },
          {
            "code" : "Z2HC0100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2HD1101",
            "display" : "[壁深達度] M"
          },
          {
            "code" : "Z2HD1102",
            "display" : "[壁深達度] FM(胆管癌)"
          },
          {
            "code" : "Z2HD1103",
            "display" : "[壁深達度] MP"
          },
          {
            "code" : "Z2HD1104",
            "display" : "[壁深達度] SS"
          },
          {
            "code" : "Z2HD1105",
            "display" : "[壁深達度] SE"
          },
          {
            "code" : "Z2HD1106",
            "display" : "[壁深達度] SI"
          },
          {
            "code" : "Z2HD1201",
            "display" : "S0"
          },
          {
            "code" : "Z2HD1202",
            "display" : "S1"
          },
          {
            "code" : "Z2HD1203",
            "display" : "S2"
          },
          {
            "code" : "Z2HD1204",
            "display" : "S3"
          },
          {
            "code" : "Z2HD1205",
            "display" : "SX"
          },
          {
            "code" : "Z2HD1301",
            "display" : "Hinf0"
          },
          {
            "code" : "Z2HD1302",
            "display" : "Hinf1"
          },
          {
            "code" : "Z2HD1303",
            "display" : "Hinf2"
          },
          {
            "code" : "Z2HD1304",
            "display" : "Hinf3"
          },
          {
            "code" : "Z2HD1305",
            "display" : "HinfX"
          },
          {
            "code" : "Z2HD1401",
            "display" : "H0"
          },
          {
            "code" : "Z2HD1402",
            "display" : "H1"
          },
          {
            "code" : "Z2HD1403",
            "display" : "H2"
          },
          {
            "code" : "Z2HD1404",
            "display" : "H3"
          },
          {
            "code" : "Z2HD1405",
            "display" : "HX"
          },
          {
            "code" : "Z2HD1501",
            "display" : "Binf(胆嚢癌)0"
          },
          {
            "code" : "Z2HD1502",
            "display" : "Binf(胆嚢癌)1"
          },
          {
            "code" : "Z2HD1503",
            "display" : "Binf(胆嚢癌)2"
          },
          {
            "code" : "Z2HD1504",
            "display" : "Binf(胆嚢癌)3"
          },
          {
            "code" : "Z2HD1505",
            "display" : "Binf(胆嚢癌)X"
          },
          {
            "code" : "Z2HD1601",
            "display" : "Ginf(胆管癌)0"
          },
          {
            "code" : "Z2HD1602",
            "display" : "Ginf(胆管癌)1"
          },
          {
            "code" : "Z2HD1603",
            "display" : "Ginf(胆管癌)2"
          },
          {
            "code" : "Z2HD1604",
            "display" : "Ginf(胆管癌)3"
          },
          {
            "code" : "Z2HD1605",
            "display" : "Ginf(胆管癌)X"
          },
          {
            "code" : "Z2HD1701",
            "display" : "Panc(胆管癌)0"
          },
          {
            "code" : "Z2HD1702",
            "display" : "Panc(胆管癌)1"
          },
          {
            "code" : "Z2HD1703",
            "display" : "Panc(胆管癌)2"
          },
          {
            "code" : "Z2HD1704",
            "display" : "Panc(胆管癌)3"
          },
          {
            "code" : "Z2HD1705",
            "display" : "Panc(胆管癌)X"
          },
          {
            "code" : "Z2HD1801",
            "display" : "Du(胆管癌)0"
          },
          {
            "code" : "Z2HD1802",
            "display" : "Du(胆管癌)1"
          },
          {
            "code" : "Z2HD1803",
            "display" : "Du(胆管癌)2"
          },
          {
            "code" : "Z2HD1804",
            "display" : "Du(胆管癌)3"
          },
          {
            "code" : "Z2HD1805",
            "display" : "Du(胆管癌)X"
          },
          {
            "code" : "Z2HD1901",
            "display" : "PV0"
          },
          {
            "code" : "Z2HD1902",
            "display" : "PV1"
          },
          {
            "code" : "Z2HD1903",
            "display" : "PV2"
          },
          {
            "code" : "Z2HD1904",
            "display" : "PV3"
          },
          {
            "code" : "Z2HD1905",
            "display" : "PVX"
          },
          {
            "code" : "Z2HD1A01",
            "display" : "A0"
          },
          {
            "code" : "Z2HD1A02",
            "display" : "A1"
          },
          {
            "code" : "Z2HD1A03",
            "display" : "A2"
          },
          {
            "code" : "Z2HD1A04",
            "display" : "A3"
          },
          {
            "code" : "Z2HD1A05",
            "display" : "AX"
          },
          {
            "code" : "Z2HD1B01",
            "display" : "P0"
          },
          {
            "code" : "Z2HD1B02",
            "display" : "P1"
          },
          {
            "code" : "Z2HD1B03",
            "display" : "P2"
          },
          {
            "code" : "Z2HD1B04",
            "display" : "P3"
          },
          {
            "code" : "Z2HD1B05",
            "display" : "PX"
          },
          {
            "code" : "Z2HD1C01",
            "display" : "N0"
          },
          {
            "code" : "Z2HD1C02",
            "display" : "N1"
          },
          {
            "code" : "Z2HD1C03",
            "display" : "N2"
          },
          {
            "code" : "Z2HD1C04",
            "display" : "N3"
          },
          {
            "code" : "Z2HD1C05",
            "display" : "NX"
          },
          {
            "code" : "Z2M30200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2M30301",
            "display" : "[膵癌] 通常型膵管癌"
          },
          {
            "code" : "Z2M30302",
            "display" : "[膵癌] 退形成性膵管癌"
          },
          {
            "code" : "Z2M30401",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 主膵管型"
          },
          {
            "code" : "Z2M30402",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 分枝型"
          },
          {
            "code" : "Z2M30403",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 混合型"
          },
          {
            "code" : "Z2M30501",
            "display" : "[粘液性嚢胞腫瘍〔MCN〕] 粘液性嚢胞腺腫,MCA"
          },
          {
            "code" : "Z2M30502",
            "display" : "[粘液性嚢胞腫瘍〔MCN〕] 粘液性嚢胞腺癌,MCC"
          },
          {
            "code" : "Z2M30601",
            "display" : "[漿液性嚢胞腫瘍〔SCN〕] 漿液性嚢胞腺腫,SCA"
          },
          {
            "code" : "Z2M30602",
            "display" : "[漿液性嚢胞腫瘍〔SCN〕] 漿液性嚢胞腺癌,SCC"
          },
          {
            "code" : "Z2M30700",
            "display" : "膵腺房細胞癌"
          },
          {
            "code" : "Z2M30801",
            "display" : "[膵内分泌腫瘍] カルチノイド腫瘍 G1"
          },
          {
            "code" : "Z2M30802",
            "display" : "[膵内分泌腫瘍] PDNET G2"
          },
          {
            "code" : "Z2M30803",
            "display" : "[膵内分泌腫瘍] 膵内分泌癌 PDNEC G3"
          },
          {
            "code" : "Z2M30900",
            "display" : "Solid-pseudopapillary腫瘍〔SPN〕"
          },
          {
            "code" : "Z2M31000",
            "display" : "膵悪性リンパ腫"
          },
          {
            "code" : "Z2M31101",
            "display" : "[転移性膵腫瘍] 腎癌による"
          },
          {
            "code" : "Z2M31102",
            "display" : "[転移性膵腫瘍] 大腸癌による"
          },
          {
            "code" : "Z2M31201",
            "display" : "[悪性膵管狭窄] 腎癌による"
          },
          {
            "code" : "Z2M31202",
            "display" : "[悪性膵管狭窄] 大腸癌による"
          },
          {
            "code" : "Z2M31301",
            "display" : "[その他の膵腫瘍] リンパ上皮嚢胞"
          },
          {
            "code" : "Z2M31302",
            "display" : "[その他の膵腫瘍] 類表皮嚢胞"
          },
          {
            "code" : "Z2M31303",
            "display" : "[その他の膵腫瘍] 類皮嚢胞"
          },
          {
            "code" : "Z2M31401",
            "display" : "[膵術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2M31402",
            "display" : "[膵術後] 膵体尾部切除術後"
          },
          {
            "code" : "Z2M31403",
            "display" : "[膵術後] 膵分節切除術後"
          },
          {
            "code" : "Z2M31404",
            "display" : "[膵術後] 膵腫瘍核出術後"
          },
          {
            "code" : "Z2M31405",
            "display" : "[膵術後] 膵仮性嚢胞・膿瘍ドレナージ術後"
          },
          {
            "code" : "Z2M31501",
            "display" : "[慢性膵炎] 膵石"
          },
          {
            "code" : "Z2M31502",
            "display" : "[慢性膵炎] 遺伝性"
          },
          {
            "code" : "Z2M31600",
            "display" : "腫瘤形成性膵炎"
          },
          {
            "code" : "Z2M31700",
            "display" : "自己免疫性膵炎"
          },
          {
            "code" : "Z2M31800",
            "display" : "仮性嚢胞"
          },
          {
            "code" : "Z2M31901",
            "display" : "[良性膵管狭窄] 結石"
          },
          {
            "code" : "Z2M31902",
            "display" : "[良性膵管狭窄] 術後狭窄"
          },
          {
            "code" : "Z2M32000",
            "display" : "単純性膵管拡張"
          },
          {
            "code" : "Z2M32100",
            "display" : "単純性嚢胞"
          },
          {
            "code" : "Z2M32200",
            "display" : "その他の非腫瘍性嚢胞（記述する）"
          },
          {
            "code" : "Z2M32301",
            "display" : "[膵管癒合不全] 完全型"
          },
          {
            "code" : "Z2M32302",
            "display" : "[膵管癒合不全] 不完全型"
          },
          {
            "code" : "Z2M32400",
            "display" : "輪状膵"
          },
          {
            "code" : "Z2M32500",
            "display" : "寄生虫"
          },
          {
            "code" : "Z2M30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2MC0200",
            "display" : "異常所見なし"
          },
          {
            "code" : "Z2MC0300",
            "display" : "膵病変描出出来ず"
          },
          {
            "code" : "Z2MC0401",
            "display" : "[膵癌] 通常型膵管癌"
          },
          {
            "code" : "Z2MC0402",
            "display" : "[膵癌] 退形成性膵管癌"
          },
          {
            "code" : "Z2MC0501",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 主膵管型"
          },
          {
            "code" : "Z2MC0502",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 分枝型"
          },
          {
            "code" : "Z2MC0503",
            "display" : "[膵管内乳頭粘液性腫瘍〔IPMN〕] 混合型"
          },
          {
            "code" : "Z2MC0601",
            "display" : "[粘液性嚢胞腫瘍〔MCN〕] 粘液性嚢胞腺腫,MCA"
          },
          {
            "code" : "Z2MC0602",
            "display" : "[粘液性嚢胞腫瘍〔MCN〕] 粘液性嚢胞腺癌,MCC"
          },
          {
            "code" : "Z2MC0701",
            "display" : "[漿液性嚢胞腫瘍〔SCN〕] 漿液性嚢胞腺腫,SCA"
          },
          {
            "code" : "Z2MC0702",
            "display" : "[漿液性嚢胞腫瘍〔SCN〕] 漿液性嚢胞腺癌,SCC"
          },
          {
            "code" : "Z2MC0800",
            "display" : "膵腺房細胞癌"
          },
          {
            "code" : "Z2MC0901",
            "display" : "[膵内分泌腫瘍] カルチノイド腫瘍 G1"
          },
          {
            "code" : "Z2MC0902",
            "display" : "[膵内分泌腫瘍] PDNET G2"
          },
          {
            "code" : "Z2MC0903",
            "display" : "[膵内分泌腫瘍] 膵内分泌癌 PDNEC G3"
          },
          {
            "code" : "Z2MC1000",
            "display" : "Solid-pseudopapillary腫瘍〔SPN〕"
          },
          {
            "code" : "Z2MC1100",
            "display" : "膵悪性リンパ腫"
          },
          {
            "code" : "Z2MC1201",
            "display" : "[転移性膵腫瘍] 腎癌による"
          },
          {
            "code" : "Z2MC1202",
            "display" : "[転移性膵腫瘍] 大腸癌による"
          },
          {
            "code" : "Z2MC1301",
            "display" : "[悪性膵管狭窄] 腎癌による"
          },
          {
            "code" : "Z2MC1302",
            "display" : "[悪性膵管狭窄] 大腸癌による"
          },
          {
            "code" : "Z2MC1401",
            "display" : "[その他の膵腫瘍] リンパ上皮嚢胞"
          },
          {
            "code" : "Z2MC1402",
            "display" : "[その他の膵腫瘍] 類表皮嚢胞"
          },
          {
            "code" : "Z2MC1403",
            "display" : "[その他の膵腫瘍] 類皮嚢胞"
          },
          {
            "code" : "Z2MC1501",
            "display" : "[膵術後] 膵頭十二指腸切除術後"
          },
          {
            "code" : "Z2MC1502",
            "display" : "[膵術後] 膵体尾部切除術後"
          },
          {
            "code" : "Z2MC1503",
            "display" : "[膵術後] 膵分節切除術後"
          },
          {
            "code" : "Z2MC1504",
            "display" : "[膵術後] 膵腫瘍核出術後"
          },
          {
            "code" : "Z2MC1505",
            "display" : "[膵術後] 膵仮性嚢胞・膿瘍ドレナージ術後"
          },
          {
            "code" : "Z2MC1601",
            "display" : "[慢性膵炎] 膵石"
          },
          {
            "code" : "Z2MC1602",
            "display" : "[慢性膵炎] 遺伝性"
          },
          {
            "code" : "Z2MC1700",
            "display" : "腫瘤形成性膵炎"
          },
          {
            "code" : "Z2MC1800",
            "display" : "自己免疫性膵炎"
          },
          {
            "code" : "Z2MC1900",
            "display" : "仮性嚢胞"
          },
          {
            "code" : "Z2MC2001",
            "display" : "[良性膵管狭窄] 結石"
          },
          {
            "code" : "Z2MC2002",
            "display" : "[良性膵管狭窄] 術後狭窄"
          },
          {
            "code" : "Z2MC2100",
            "display" : "単純性膵管拡張"
          },
          {
            "code" : "Z2MC2200",
            "display" : "単純性嚢胞"
          },
          {
            "code" : "Z2MC2300",
            "display" : "その他の非腫瘍性嚢胞"
          },
          {
            "code" : "Z2MC2401",
            "display" : "[膵管癒合不全] 完全型"
          },
          {
            "code" : "Z2MC2402",
            "display" : "[膵管癒合不全] 不完全型"
          },
          {
            "code" : "Z2MC2500",
            "display" : "輪状膵"
          },
          {
            "code" : "Z2MC2600",
            "display" : "寄生虫"
          },
          {
            "code" : "Z2MC2701",
            "display" : "[内視鏡治療後] ステント挿入後"
          },
          {
            "code" : "Z2MC0100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2MD1101",
            "display" : "TS1"
          },
          {
            "code" : "Z2MD1102",
            "display" : "TS2"
          },
          {
            "code" : "Z2MD1103",
            "display" : "TS3"
          },
          {
            "code" : "Z2MD1104",
            "display" : "TS4"
          },
          {
            "code" : "Z2MD1105",
            "display" : "TSX"
          },
          {
            "code" : "Z2MD1201",
            "display" : "Tis"
          },
          {
            "code" : "Z2MD1202",
            "display" : "T1"
          },
          {
            "code" : "Z2MD1203",
            "display" : "T2"
          },
          {
            "code" : "Z2MD1204",
            "display" : "T3"
          },
          {
            "code" : "Z2MD1205",
            "display" : "T4"
          },
          {
            "code" : "Z2MD1206",
            "display" : "TX"
          },
          {
            "code" : "Z2MD1301",
            "display" : "CH－"
          },
          {
            "code" : "Z2MD1302",
            "display" : "CH＋"
          },
          {
            "code" : "Z2MD1303",
            "display" : "CHX"
          },
          {
            "code" : "Z2MD1401",
            "display" : "DU－"
          },
          {
            "code" : "Z2MD1402",
            "display" : "DU＋"
          },
          {
            "code" : "Z2MD1403",
            "display" : "DUX"
          },
          {
            "code" : "Z2MD1501",
            "display" : "S－"
          },
          {
            "code" : "Z2MD1502",
            "display" : "S＋"
          },
          {
            "code" : "Z2MD1503",
            "display" : "SX"
          },
          {
            "code" : "Z2MD1601",
            "display" : "RP－"
          },
          {
            "code" : "Z2MD1602",
            "display" : "RP＋"
          },
          {
            "code" : "Z2MD1603",
            "display" : "RPX"
          },
          {
            "code" : "Z2MD1701",
            "display" : "PV－"
          },
          {
            "code" : "Z2MD1702",
            "display" : "PV＋"
          },
          {
            "code" : "Z2MD1703",
            "display" : "PVX"
          },
          {
            "code" : "Z2MD1801",
            "display" : "A－"
          },
          {
            "code" : "Z2MD1802",
            "display" : "A＋"
          },
          {
            "code" : "Z2MD1803",
            "display" : "AX"
          },
          {
            "code" : "Z2MD1901",
            "display" : "PL－"
          },
          {
            "code" : "Z2MD1902",
            "display" : "PL＋"
          },
          {
            "code" : "Z2MD1903",
            "display" : "PLX"
          },
          {
            "code" : "Z2MD1A01",
            "display" : "OO－"
          },
          {
            "code" : "Z2MD1A02",
            "display" : "OO＋"
          },
          {
            "code" : "Z2MD1A03",
            "display" : "OOX"
          },
          {
            "code" : "Z2MD1B01",
            "display" : "N0"
          },
          {
            "code" : "Z2MD1B02",
            "display" : "N1"
          },
          {
            "code" : "Z2MD1B03",
            "display" : "N2"
          },
          {
            "code" : "Z2MD1B04",
            "display" : "N3"
          },
          {
            "code" : "Z2MD1B05",
            "display" : "NX"
          },
          {
            "code" : "Z2J30200",
            "display" : "特記所見なし"
          },
          {
            "code" : "Z2J30301",
            "display" : "[上皮性腫瘍] 腺腫"
          },
          {
            "code" : "Z2J30302",
            "display" : "[上皮性腫瘍] 癌"
          },
          {
            "code" : "Z2J30303",
            "display" : "[上皮性腫瘍] 神経内分泌腫瘍"
          },
          {
            "code" : "Z2J303ZZ",
            "display" : "[上皮性腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2J30401",
            "display" : "[ポリポーシス] 家族性大腸腺腫症"
          },
          {
            "code" : "Z2J30402",
            "display" : "[ポリポーシス] Peutz-Jeghers症候群"
          },
          {
            "code" : "Z2J30403",
            "display" : "[ポリポーシス] Cronkhite-Canada症候群"
          },
          {
            "code" : "Z2J30404",
            "display" : "[ポリポーシス] Cowden病"
          },
          {
            "code" : "Z2J304ZZ",
            "display" : "[ポリポーシス] その他（記述する）"
          },
          {
            "code" : "Z2J30501",
            "display" : "[悪性リンパ腫] 濾胞性リンパ腫"
          },
          {
            "code" : "Z2J30502",
            "display" : "[悪性リンパ腫] DLBCL"
          },
          {
            "code" : "Z2J30503",
            "display" : "[悪性リンパ腫] T細胞リンパ腫"
          },
          {
            "code" : "Z2J305ZZ",
            "display" : "[悪性リンパ腫] その他（記述する）"
          },
          {
            "code" : "Z2J30601",
            "display" : "[粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2J30602",
            "display" : "[粘膜下腫瘍] 平滑筋肉腫"
          },
          {
            "code" : "Z2J30603",
            "display" : "[粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2J30604",
            "display" : "[粘膜下腫瘍] 嚢胞"
          },
          {
            "code" : "Z2J30605",
            "display" : "[粘膜下腫瘍] 異所性膵組織"
          },
          {
            "code" : "Z2J30606",
            "display" : "[粘膜下腫瘍] リンパ管腫"
          },
          {
            "code" : "Z2J30607",
            "display" : "[粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2J30608",
            "display" : "[粘膜下腫瘍] 血管腫"
          },
          {
            "code" : "Z2J30609",
            "display" : "[粘膜下腫瘍] 神経鞘腫"
          },
          {
            "code" : "Z2J30610",
            "display" : "[粘膜下腫瘍] 悪性神経鞘腫"
          },
          {
            "code" : "Z2J306ZZ",
            "display" : "[粘膜下腫瘍] その他の粘膜下腫瘍（記述する）"
          },
          {
            "code" : "Z2J30701",
            "display" : "[転移性腫瘍] 他臓器癌転移"
          },
          {
            "code" : "Z2J30702",
            "display" : "[転移性腫瘍] 他臓器癌直接浸潤"
          },
          {
            "code" : "Z2J30801",
            "display" : "[その他の腫瘍] 悪性黒色腫"
          },
          {
            "code" : "Z2J30802",
            "display" : "[その他の腫瘍] 形質細胞腫"
          },
          {
            "code" : "Z2J30803",
            "display" : "[その他の腫瘍] カポジ肉腫"
          },
          {
            "code" : "Z2J30804",
            "display" : "[その他の腫瘍] その他の腫瘍"
          },
          {
            "code" : "Z2J30901",
            "display" : "[治療後評価] CRT後"
          },
          {
            "code" : "Z2J30902",
            "display" : "[治療後評価] RT後"
          },
          {
            "code" : "Z2J30903",
            "display" : "[治療後評価] Chemotherapy後"
          },
          {
            "code" : "Z2J30904",
            "display" : "[治療後評価] 無治療経過観察後"
          },
          {
            "code" : "Z2J31001",
            "display" : "[内視鏡治療後評価] 内視鏡治療後"
          },
          {
            "code" : "Z2J31101",
            "display" : "[炎症] クローン病"
          },
          {
            "code" : "Z2J31102",
            "display" : "[炎症] ベーチェット病・単純性潰瘍"
          },
          {
            "code" : "Z2J31103",
            "display" : "[炎症] 非特異性多発性小腸潰瘍"
          },
          {
            "code" : "Z2J31104",
            "display" : "[炎症] 好酸球性腸炎"
          },
          {
            "code" : "Z2J31105",
            "display" : "[炎症] 薬剤性腸炎"
          },
          {
            "code" : "Z2J31106",
            "display" : "[炎症] 放射線性腸炎"
          },
          {
            "code" : "Z2J31107",
            "display" : "[炎症] 感染性腸炎"
          },
          {
            "code" : "Z2J31108",
            "display" : "[炎症] 腸結核"
          },
          {
            "code" : "Z2J31109",
            "display" : "[炎症] GVHD"
          },
          {
            "code" : "Z2J31110",
            "display" : "[炎症] TMA"
          },
          {
            "code" : "Z2J31111",
            "display" : "[炎症] 非特異性小腸炎"
          },
          {
            "code" : "Z2J311ZZ",
            "display" : "[炎症] その他（記述する）"
          },
          {
            "code" : "Z2J31201",
            "display" : "[血管性病変] 血管拡張症（矢野山本１a）"
          },
          {
            "code" : "Z2J31202",
            "display" : "[血管性病変] 血管拡張症（矢野山本１b）"
          },
          {
            "code" : "Z2J31203",
            "display" : "[血管性病変] デュラホイ病変（矢野山本2a）"
          },
          {
            "code" : "Z2J31204",
            "display" : "[血管性病変] デュラホイ病変（矢野山本2b）"
          },
          {
            "code" : "Z2J31205",
            "display" : "[血管性病変] 動静脈奇形（矢野山本3）"
          },
          {
            "code" : "Z2J312ZZ",
            "display" : "[血管性病変] その他（矢野山本4）（記述する）"
          },
          {
            "code" : "Z2J31206",
            "display" : "[血管性病変] 静脈瘤"
          },
          {
            "code" : "Z2J30101",
            "display" : "[その他] 憩室"
          },
          {
            "code" : "Z2J30102",
            "display" : "[その他] メッケル憩室"
          },
          {
            "code" : "Z2J30103",
            "display" : "[その他] 寄生虫"
          },
          {
            "code" : "Z2J30104",
            "display" : "[その他] アミロイドーシス"
          },
          {
            "code" : "Z2J30105",
            "display" : "[その他] サルコイドーシス"
          },
          {
            "code" : "Z2J30106",
            "display" : "[その他] 全身性疾患に伴うもの"
          },
          {
            "code" : "Z2J301ZZ",
            "display" : "[その他] その他（記述する）"
          },
          {
            "code" : "Z2L30200",
            "display" : "特記所見なし"
          },
          {
            "code" : "Z2L30301",
            "display" : "[腫瘍] 腺腫・早期大腸癌"
          },
          {
            "code" : "Z2L30311",
            "display" : "[腫瘍] 進行大腸癌"
          },
          {
            "code" : "Z2L30401",
            "display" : "[鋸歯状病変] HP"
          },
          {
            "code" : "Z2L30402",
            "display" : "[鋸歯状病変] SSA/P"
          },
          {
            "code" : "Z2L30403",
            "display" : "[鋸歯状病変] TSA"
          },
          {
            "code" : "Z2L30404",
            "display" : "[鋸歯状病変] Mixed type"
          },
          {
            "code" : "Z2L30501",
            "display" : "[悪性リンパ腫] MALTリンパ腫"
          },
          {
            "code" : "Z2L30502",
            "display" : "[悪性リンパ腫] DLBCL"
          },
          {
            "code" : "Z2L305ZZ",
            "display" : "[悪性リンパ腫] その他（記述する）"
          },
          {
            "code" : "Z2L30601",
            "display" : "[粘膜下腫瘍] 平滑筋腫"
          },
          {
            "code" : "Z2L30602",
            "display" : "[粘膜下腫瘍] 平滑筋肉腫"
          },
          {
            "code" : "Z2L30603",
            "display" : "[粘膜下腫瘍] GIST"
          },
          {
            "code" : "Z2L30604",
            "display" : "[粘膜下腫瘍] 嚢胞"
          },
          {
            "code" : "Z2L30605",
            "display" : "[粘膜下腫瘍] リンパ管腫"
          },
          {
            "code" : "Z2L30606",
            "display" : "[粘膜下腫瘍] 脂肪腫"
          },
          {
            "code" : "Z2L30607",
            "display" : "[粘膜下腫瘍] カルチノイド"
          },
          {
            "code" : "Z2L306ZZ",
            "display" : "[粘膜下腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2L30701",
            "display" : "[転移性腫瘍] 他臓器癌転移"
          },
          {
            "code" : "Z2L30702",
            "display" : "[転移性腫瘍] 他臓器癌直接浸潤"
          },
          {
            "code" : "Z2L30801",
            "display" : "[その他の腫瘍] 悪性黒色腫"
          },
          {
            "code" : "Z2L30802",
            "display" : "[その他の腫瘍] 肛門管癌"
          },
          {
            "code" : "Z2L30803",
            "display" : "[その他の腫瘍] 神経内分泌癌"
          },
          {
            "code" : "Z2L308ZZ",
            "display" : "[その他の腫瘍] その他（記述する）"
          },
          {
            "code" : "Z2L30901",
            "display" : "[内視鏡治療後] 遺残再発あり"
          },
          {
            "code" : "Z2L30902",
            "display" : "[内視鏡治療後] 遺残再発なし"
          },
          {
            "code" : "Z2L309ZZ",
            "display" : "[内視鏡治療後] その他（記述する）"
          },
          {
            "code" : "Z2L31001",
            "display" : "[局所切除後（外科手術）] 吻合部再発：有"
          },
          {
            "code" : "Z2L31002",
            "display" : "[局所切除後（外科手術）] 吻合部再発：無"
          },
          {
            "code" : "Z2L31011",
            "display" : "[局所切除後（外科手術）] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31012",
            "display" : "[局所切除後（外科手術）] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31101",
            "display" : "[回盲部切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31102",
            "display" : "[回盲部切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31111",
            "display" : "[回盲部切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31112",
            "display" : "[回盲部切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31201",
            "display" : "[右半結腸切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31202",
            "display" : "[右半結腸切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31211",
            "display" : "[右半結腸切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31212",
            "display" : "[右半結腸切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31301",
            "display" : "[横行結腸切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31302",
            "display" : "[横行結腸切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31311",
            "display" : "[横行結腸切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31312",
            "display" : "[横行結腸切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31401",
            "display" : "[左半結腸切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31402",
            "display" : "[左半結腸切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31411",
            "display" : "[左半結腸切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31412",
            "display" : "[左半結腸切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31501",
            "display" : "[下行結腸切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31502",
            "display" : "[下行結腸切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31511",
            "display" : "[下行結腸切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31512",
            "display" : "[下行結腸切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31601",
            "display" : "[S状結腸切除後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31602",
            "display" : "[S状結腸切除後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31611",
            "display" : "[S状結腸切除後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31612",
            "display" : "[S状結腸切除後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31701",
            "display" : "[HAR後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31702",
            "display" : "[HAR後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31711",
            "display" : "[HAR後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31712",
            "display" : "[HAR後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31801",
            "display" : "[LAR後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31802",
            "display" : "[LAR後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31811",
            "display" : "[LAR後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31812",
            "display" : "[LAR後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L31901",
            "display" : "[Miles’ope後] 吻合部再発：有"
          },
          {
            "code" : "Z2L31902",
            "display" : "[Miles’ope後] 吻合部再発：無"
          },
          {
            "code" : "Z2L31911",
            "display" : "[Miles’ope後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L31912",
            "display" : "[Miles’ope後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L32001",
            "display" : "[FAP術後] 吻合部再発：有"
          },
          {
            "code" : "Z2L32002",
            "display" : "[FAP術後] 吻合部再発：無"
          },
          {
            "code" : "Z2L32011",
            "display" : "[FAP術後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L32012",
            "display" : "[FAP術後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L32101",
            "display" : "[Hartmann手術後] 吻合部再発：有"
          },
          {
            "code" : "Z2L32102",
            "display" : "[Hartmann手術後] 吻合部再発：無"
          },
          {
            "code" : "Z2L32111",
            "display" : "[Hartmann手術後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L32112",
            "display" : "[Hartmann手術後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L32201",
            "display" : "[大腸全摘後] 吻合部再発：有"
          },
          {
            "code" : "Z2L32202",
            "display" : "[大腸全摘後] 吻合部再発：無"
          },
          {
            "code" : "Z2L32211",
            "display" : "[大腸全摘後] 吻合部狭窄：有"
          },
          {
            "code" : "Z2L32212",
            "display" : "[大腸全摘後] 吻合部狭窄：無"
          },
          {
            "code" : "Z2L32301",
            "display" : "[家族性大腸腺腫症（FAP)] 密生型"
          },
          {
            "code" : "Z2L32302",
            "display" : "[家族性大腸腺腫症（FAP)] 非密生型"
          },
          {
            "code" : "Z2L32400",
            "display" : "Gardner症候群"
          },
          {
            "code" : "Z2L32500",
            "display" : "Cronkhite-Canada症候群"
          },
          {
            "code" : "Z2L32600",
            "display" : "Peutz-Jeghers症候群"
          },
          {
            "code" : "Z2L32700",
            "display" : "若年性ポリポーシス"
          },
          {
            "code" : "Z2L32801",
            "display" : "[Serrated polyposis syndrome（SPS）] 10mm以上が2個以上"
          },
          {
            "code" : "Z2L32802",
            "display" : "[Serrated polyposis syndrome（SPS）] 20個以上"
          },
          {
            "code" : "Z2L30100",
            "display" : "その他（記述する）"
          },
          {
            "code" : "Z2L32901",
            "display" : "[潰瘍性大腸炎] 直腸炎型"
          },
          {
            "code" : "Z2L32902",
            "display" : "[潰瘍性大腸炎] 左側大腸炎型"
          },
          {
            "code" : "Z2L32903",
            "display" : "[潰瘍性大腸炎] 全大腸炎型"
          },
          {
            "code" : "Z2L32904",
            "display" : "[潰瘍性大腸炎] 右側型（分節型）"
          },
          {
            "code" : "Z2L33001",
            "display" : "[Crohn病] 大腸型"
          },
          {
            "code" : "Z2L33002",
            "display" : "[Crohn病] 小腸大腸型"
          },
          {
            "code" : "Z2L33003",
            "display" : "[Crohn病] 小腸型"
          },
          {
            "code" : "Z2L33100",
            "display" : "虚血性腸炎"
          },
          {
            "code" : "Z2L33200",
            "display" : "放射線性腸炎"
          },
          {
            "code" : "Z2L33300",
            "display" : "出血性腸炎"
          },
          {
            "code" : "Z2L33400",
            "display" : "偽膜性腸炎"
          },
          {
            "code" : "Z2L33500",
            "display" : "病原性大腸菌腸炎"
          },
          {
            "code" : "Z2L33600",
            "display" : "アフタ様大腸炎"
          },
          {
            "code" : "Z2L33700",
            "display" : "腸管ベーチェット"
          },
          {
            "code" : "Z2L33800",
            "display" : "単純性潰瘍"
          },
          {
            "code" : "Z2L33900",
            "display" : "感染性腸炎"
          },
          {
            "code" : "Z2L34000",
            "display" : "アメーバ腸炎"
          },
          {
            "code" : "Z2L34100",
            "display" : "腸結核"
          },
          {
            "code" : "Z2L34200",
            "display" : "GVHD"
          },
          {
            "code" : "Z2L34300",
            "display" : "サイトメガロ腸炎"
          },
          {
            "code" : "Z2L34400",
            "display" : "憩室"
          },
          {
            "code" : "Z2L34500",
            "display" : "痔核"
          },
          {
            "code" : "Z2L34600",
            "display" : "偽メラノーシス"
          },
          {
            "code" : "Z2L34700",
            "display" : "直腸潰瘍"
          },
          {
            "code" : "Z2L34800",
            "display" : "粘膜逸脱症候群（MPS)"
          },
          {
            "code" : "Z2L34900",
            "display" : "腸管嚢胞性気腫症"
          },
          {
            "code" : "Z2L35000",
            "display" : "腸捻転"
          },
          {
            "code" : "Z2L35100",
            "display" : "内視鏡治療後出血"
          },
          {
            "code" : "Z2L35200",
            "display" : "憩室出血"
          },
          {
            "code" : "Z2L35300",
            "display" : "その他の出血（記述する）"
          },
          {
            "code" : "Z2L35400",
            "display" : "IBDに伴う狭窄"
          },
          {
            "code" : "Z2L35500",
            "display" : "collagenous colitis"
          },
          {
            "code" : "Z2L35600",
            "display" : "その他の非腫瘍性病変（記述する）"
          }
        ]
      }
    ]
  }
}

```
