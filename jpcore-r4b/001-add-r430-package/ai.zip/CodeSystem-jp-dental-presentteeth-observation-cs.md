# JP Core Dental PresentTeethObservation CodeSystem - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Dental PresentTeethObservation CodeSystem**

## CodeSystem: JP Core Dental PresentTeethObservation CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalPresentTeethObservation_CS
* **項目**: *Version*
  * **内容**: 2.0.0-dev
* **項目**: *Name*
  * **内容**: JP_DentalPresentTeethObservation_CS
* **項目**: *Title*
  * **内容**: JP Core Dental PresentTeethObservation CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2024-12-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義した歯科のObservationリソースに関する現存歯の観察結果コード 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_DentalPresentTeethObservation_VS](ValueSet-jp-dental-presentteeth-observation-vs.md)
* [JP_DentalTeethObservation_VS](ValueSet-jp-dental-teethobservation-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-dental-presentteeth-observation-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalPresentTeethObservation_CS",
  "version" : "2.0.0-dev",
  "name" : "JP_DentalPresentTeethObservation_CS",
  "title" : "JP Core Dental PresentTeethObservation CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義した歯科のObservationリソースに関する現存歯の観察結果コード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 278,
  "concept" : [
    {
      "code" : "TP-3-01",
      "display" : "生活歯"
    },
    {
      "code" : "TP-3-02",
      "display" : "失活歯"
    },
    {
      "code" : "TP-3-03",
      "display" : "失活歯（歯根端切除歯）"
    },
    {
      "code" : "TP-4-01",
      "display" : "半埋伏歯（ＨＲＴ）"
    },
    {
      "code" : "TP-4-02",
      "display" : "半埋伏歯（ＨＲＴ）（水平）"
    },
    {
      "code" : "TP-4-03",
      "display" : "埋伏歯（ＲＴ）（詳細不明）"
    },
    {
      "code" : "TP-4-04",
      "display" : "埋伏歯（ＲＴ）（水平）"
    },
    {
      "code" : "TP-4-05",
      "display" : "埋伏歯（完全）（ＣＲＴ）"
    },
    {
      "code" : "TP-4-06",
      "display" : "水平埋伏智歯（ＨＩＴ）"
    },
    {
      "code" : "TP-4-07",
      "display" : "未萌出歯"
    },
    {
      "code" : "TP-4-08",
      "display" : "萌出途中"
    },
    {
      "code" : "TP-5-01",
      "display" : "捻転歯（ＲＯＴ）"
    },
    {
      "code" : "TP-5-02",
      "display" : "転位歯"
    },
    {
      "code" : "TP-5-03",
      "display" : "傾斜歯"
    },
    {
      "code" : "TP-5-04",
      "display" : "叢生"
    },
    {
      "code" : "TP-5-05",
      "display" : "歯間離開"
    },
    {
      "code" : "TP-5-06",
      "display" : "歯の位置異常（その他）"
    },
    {
      "code" : "TP-6-01",
      "display" : "遠心頬側根"
    },
    {
      "code" : "TP-6-02",
      "display" : "近心頬側根"
    },
    {
      "code" : "TP-6-03",
      "display" : "近心頬側根および遠心頬側根"
    },
    {
      "code" : "TP-6-04",
      "display" : "舌側（口蓋）根"
    },
    {
      "code" : "TP-6-05",
      "display" : "舌側（口蓋）根および遠心頬側根"
    },
    {
      "code" : "TP-6-06",
      "display" : "舌側（口蓋）根および近心頬側根"
    },
    {
      "code" : "TP-6-07",
      "display" : "遠心根"
    },
    {
      "code" : "TP-6-08",
      "display" : "近心根"
    },
    {
      "code" : "TP-6-09",
      "display" : "歯根分割歯"
    },
    {
      "code" : "TP-6-10",
      "display" : "歯根（部位不明）"
    },
    {
      "code" : "TP-7-01",
      "display" : "弯曲根"
    },
    {
      "code" : "TP-7-02",
      "display" : "癒合歯"
    },
    {
      "code" : "TP-7-03",
      "display" : "癒着歯"
    },
    {
      "code" : "TP-7-04",
      "display" : "巨大歯"
    },
    {
      "code" : "TP-7-05",
      "display" : "矮小歯"
    },
    {
      "code" : "TP-7-06",
      "display" : "円錐歯"
    },
    {
      "code" : "TP-7-07",
      "display" : "エナメル質形成不全（ＥＨｐ）"
    },
    {
      "code" : "TP-7-08",
      "display" : "斑状歯"
    },
    {
      "code" : "TP-7-09",
      "display" : "変色歯"
    },
    {
      "code" : "TP-7-10",
      "display" : "ピンク歯"
    },
    {
      "code" : "TP-7-11",
      "display" : "結節（切歯）"
    },
    {
      "code" : "TP-7-12",
      "display" : "結節（中心）"
    },
    {
      "code" : "TP-7-13",
      "display" : "結節（カラベリ）"
    },
    {
      "code" : "TP-7-14",
      "display" : "結節（臼旁）"
    },
    {
      "code" : "TP-7-15",
      "display" : "結節（臼後）"
    },
    {
      "code" : "TP-7-16",
      "display" : "歯の発育異常"
    },
    {
      "code" : "TP-7-17",
      "display" : "歯の形態異常（その他）"
    },
    {
      "code" : "TP-7-18",
      "display" : "歯の形成異常（その他）"
    },
    {
      "code" : "TP-7-19",
      "display" : "癒着歯または癒合歯"
    },
    {
      "code" : "TP-7-20",
      "display" : "歯の結節（詳細不明）"
    },
    {
      "code" : "TP-8-01",
      "display" : "過剰歯（ＳＮＴ）"
    },
    {
      "code" : "TP-8-02",
      "display" : "過剰埋伏歯"
    },
    {
      "code" : "TP-9-01",
      "display" : "う歯（未処置歯Ｃ）（程度不明）"
    },
    {
      "code" : "TP-9-02",
      "display" : "Ｃ１"
    },
    {
      "code" : "TP-9-03",
      "display" : "Ｃ２"
    },
    {
      "code" : "TP-9-04",
      "display" : "Ｃ３"
    },
    {
      "code" : "TP-9-05",
      "display" : "Ｃ１〃"
    },
    {
      "code" : "TP-9-06",
      "display" : "Ｃ２〃"
    },
    {
      "code" : "TP-9-07",
      "display" : "Ｃ３〃"
    },
    {
      "code" : "TP-9-08",
      "display" : "仮封・暫間充填（テンポラリークラウンを除く）・治療中（歯内療法中、等）"
    },
    {
      "code" : "TP-9-10",
      "display" : "残根、Ｃ４"
    },
    {
      "code" : "TP-9-11",
      "display" : "残根（残根上義歯）"
    },
    {
      "code" : "TP-9-12",
      "display" : "咬耗（Ａｔｔ）"
    },
    {
      "code" : "TP-9-13",
      "display" : "磨耗（Ａｂｒ）"
    },
    {
      "code" : "TP-9-14",
      "display" : "歯質くさび状欠損（ＷＳＤ）"
    },
    {
      "code" : "TP-9-15",
      "display" : "歯の破折（ＦｒＴ）"
    },
    {
      "code" : "TP-9-16",
      "display" : "歯の酸蝕症"
    },
    {
      "code" : "TP-9-17",
      "display" : "歯の酸蝕症疑い（±）"
    },
    {
      "code" : "TP-9-18",
      "display" : "歯の酸蝕症第１度（Ｅ１）(Ｅｒｏ)"
    },
    {
      "code" : "TP-9-19",
      "display" : "歯の酸蝕症第２度（Ｅ２）(Ｅｒｏ)"
    },
    {
      "code" : "TP-9-20",
      "display" : "歯の酸蝕症第３度（Ｅ３）(Ｅｒｏ)"
    },
    {
      "code" : "TP-9-21",
      "display" : "歯の酸蝕症第４度（Ｅ４）(Ｅｒｏ)"
    },
    {
      "code" : "TP-9-22",
      "display" : "窩洞形成歯（単純）（修復物等脱落した状態含む）"
    },
    {
      "code" : "TP-9-23",
      "display" : "窩洞形成歯（複雑）（修復物等脱落した状態含む）"
    },
    {
      "code" : "TP-9-24",
      "display" : "窩洞形成歯（単純・複雑の情報なし）（修復物等脱落した状態含む）"
    },
    {
      "code" : "TP-9-25",
      "display" : "窩洞形成歯（支台築造）（支台築造脱落した状態含む）"
    },
    {
      "code" : "TP-9-26",
      "display" : "歯冠形成歯（部分冠）（部分冠脱落した状態含む）"
    },
    {
      "code" : "TP-9-27",
      "display" : "歯冠形成歯（全部冠）（全部冠脱落した状態含む）"
    },
    {
      "code" : "TP-9-28",
      "display" : "支台築造（メタルコア・銀色）（Ｍコア）"
    },
    {
      "code" : "TP-9-29",
      "display" : "支台築造（メタルコア・黒色）（Ｍコア）"
    },
    {
      "code" : "TP-9-30",
      "display" : "支台築造（メタルコア・金色）（Ｍコア）"
    },
    {
      "code" : "TP-9-31",
      "display" : "支台築造（非金属コア・歯冠色他）（コア）"
    },
    {
      "code" : "TP-9-32",
      "display" : "歯冠形成歯（全部冠・部分冠の情報なし）（冠脱落した状態含む）"
    },
    {
      "code" : "TP-10-01",
      "display" : "部分修復のテンポラリークラウン（ＴｅＣ）"
    },
    {
      "code" : "TP-10-02",
      "display" : "全部修復のテンポラリークラウン（ＴｅＣ）"
    },
    {
      "code" : "TP-10-03",
      "display" : "その他修復のテンポラリークラウン（全部修復・部分修復の情報なしの場合含む）（ＴｅＣ）"
    },
    {
      "code" : "TP-10-04",
      "display" : "ブリッジのリテイナー（５歯以下）・クラウン（支台歯）"
    },
    {
      "code" : "TP-10-05",
      "display" : "ブリッジのリテイナー（６歯以上）・クラウン（支台歯）"
    },
    {
      "code" : "TP-10-06",
      "display" : "歯周治療用装置（冠形態）"
    },
    {
      "code" : "TP-10-07",
      "display" : "歯周治療用装置（冠形態）ブリッジ・クラウン（支台歯）"
    },
    {
      "code" : "TP-10-08",
      "display" : "プロビジョナルクラウン"
    },
    {
      "code" : "TP-10-09",
      "display" : "プロビジョナルブリッジ・クラウン（支台歯）"
    },
    {
      "code" : "TP-10-10",
      "display" : "ブリッジのリテイナー（広範囲顎骨支持型補綴（ブリッジ形態のもの））"
    },
    {
      "code" : "TP-11-01",
      "display" : "部分修復・単純窩洞（歯冠色充填）（ＣＦ、ＲＦ、ＧＣＦ）"
    },
    {
      "code" : "TP-11-02",
      "display" : "部分修復・複雑窩洞（歯冠色充填）（ＣＦ、ＲＦ、ＧＣＦ）"
    },
    {
      "code" : "TP-11-03",
      "display" : "部分修復（単純・複雑の情報なし）（歯冠色充填）（ＣＦ、ＲＦ、ＧＣＦ）"
    },
    {
      "code" : "TP-11-04",
      "display" : "部分修復・単純窩洞（アマルガム充填）（ＡＦ）"
    },
    {
      "code" : "TP-11-05",
      "display" : "部分修復・複雑窩洞（アマルガム充填）（ＡＦ）"
    },
    {
      "code" : "TP-11-06",
      "display" : "部分修復（単純・複雑の情報なし）（アマルガム充填）（ＡＦ）"
    },
    {
      "code" : "TP-11-07",
      "display" : "部分修復（金箔充填・金色）"
    },
    {
      "code" : "TP-11-08",
      "display" : "部分修復・単純窩洞（金属インレー・銀色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-09",
      "display" : "部分修復・単純窩洞（金属インレー・黒色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-10",
      "display" : "部分修復・単純窩洞（金属インレー・金色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-11",
      "display" : "部分修復・単純窩洞（非金属インレー・レジン系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-12",
      "display" : "部分修復・単純窩洞（非金属インレー・セラミック系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-13",
      "display" : "部分修復・単純窩洞（非金属インレー・材質不明、又は材質記載なし・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-14",
      "display" : "部分修復・複雑窩洞（金属インレー・銀色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-15",
      "display" : "部分修復・複雑窩洞（金属インレー・黒色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-16",
      "display" : "部分修復・複雑窩洞（金属インレー・金色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-17",
      "display" : "部分修復・複雑窩洞（非金属インレー・レジン系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-18",
      "display" : "部分修復・複雑窩洞（非金属インレー・セラミック系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-19",
      "display" : "部分修復・複雑窩洞（非金属インレー・材質不明、又は材質記載なし・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-20",
      "display" : "部分修復（単純・複雑の情報なし）（金属インレー・銀色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-21",
      "display" : "部分修復（単純・複雑の情報なし）（金属インレー・黒色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-22",
      "display" : "部分修復（単純・複雑の情報なし）（金属インレー・金色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-23",
      "display" : "部分修復（単純・複雑の情報なし）（非金属インレー・レジン系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-24",
      "display" : "部分修復（単純・複雑の情報なし）（非金属インレー・セラミック系（様）・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-25",
      "display" : "部分修復（単純・複雑の情報なし）（非金属インレー・材質不明、又は材質記載なし・歯冠色）（Ｉｎ）"
    },
    {
      "code" : "TP-11-26",
      "display" : "部分修復（金属アンレー・銀色）"
    },
    {
      "code" : "TP-11-27",
      "display" : "部分修復（金属アンレー・黒色）"
    },
    {
      "code" : "TP-11-28",
      "display" : "部分修復（金属アンレー・金色）"
    },
    {
      "code" : "TP-11-29",
      "display" : "部分修復（非金属アンレー・レジン系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-30",
      "display" : "部分修復（非金属アンレー・セラミック系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-31",
      "display" : "部分修復（非金属アンレー・材質不明、又は材質記載なし）・歯冠色）"
    },
    {
      "code" : "TP-11-32",
      "display" : "部分修復（３／４金属冠・銀色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-33",
      "display" : "部分修復（３／４金属冠・黒色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-34",
      "display" : "部分修復（３／４金属冠・金色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-35",
      "display" : "部分修復（３／４非金属冠・レジン系（様）・歯冠色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-36",
      "display" : "部分修復（３／４非金属冠・セラミック系（様）・歯冠色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-37",
      "display" : "部分修復（３／４非金属冠・材質不明、又は材質記載なし・歯冠色）（３／４Ｃｒｏ）"
    },
    {
      "code" : "TP-11-38",
      "display" : "部分修復（４／５金属冠・銀色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-39",
      "display" : "部分修復（４／５金属冠・黒色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-40",
      "display" : "部分修復（４／５金属冠・金色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-41",
      "display" : "部分修復（４／５非金属冠・レジン系（様）・歯冠色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-42",
      "display" : "部分修復（４／５非金属冠・セラミック系（様）・歯冠色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-43",
      "display" : "部分修復（４／５非金属冠・材質不明、又は材質記載なし・歯冠色）（４／５Ｃｒｏ）"
    },
    {
      "code" : "TP-11-44",
      "display" : "部分修復（ラミネートベニア・レジン系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-45",
      "display" : "部分修復（ラミネートベニア・セラミック系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-46",
      "display" : "部分修復（ラミネートベニア・材質不明、又は材質記載なし・歯冠色）"
    },
    {
      "code" : "TP-11-47",
      "display" : "部分修復（接着金属冠・銀色）"
    },
    {
      "code" : "TP-11-48",
      "display" : "部分修復（接着金属冠・黒色）"
    },
    {
      "code" : "TP-11-49",
      "display" : "部分修復（接着金属冠・金色）"
    },
    {
      "code" : "TP-11-50",
      "display" : "部分修復（接着非金属冠・レジン系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-51",
      "display" : "部分修復（接着非金属冠・セラミック系（様）・歯冠色）"
    },
    {
      "code" : "TP-11-52",
      "display" : "部分修復（接着非金属冠・材質不明、又は材質記載なし・歯冠色）"
    },
    {
      "code" : "TP-12-01",
      "display" : "単純窩洞（充填）"
    },
    {
      "code" : "TP-12-02",
      "display" : "複雑窩洞（充填）"
    },
    {
      "code" : "TP-12-03",
      "display" : "単純窩洞（インレー）"
    },
    {
      "code" : "TP-12-04",
      "display" : "複雑窩洞（インレー）"
    },
    {
      "code" : "TP-21-01",
      "display" : "全部修復（全部金属冠・銀色）（ＦＭＣ）"
    },
    {
      "code" : "TP-21-02",
      "display" : "全部修復（全部金属冠・黒色）（ＦＭＣ）"
    },
    {
      "code" : "TP-21-03",
      "display" : "全部修復（全部金属冠・金色）（ＦＭＣ）"
    },
    {
      "code" : "TP-21-04",
      "display" : "全部修復（全部非金属冠・レジン系（様）・歯冠色）（ＪＣ）"
    },
    {
      "code" : "TP-21-05",
      "display" : "全部修復（全部非金属冠・セラミック系（様）・歯冠色）（ＪＣ）"
    },
    {
      "code" : "TP-21-06",
      "display" : "全部修復（全部非金属冠・材質不明、又は材質記載なし・歯冠色）（ＪＣ）"
    },
    {
      "code" : "TP-21-07",
      "display" : "全部修復（前装金属冠・銀色）（前装ＭＣ）"
    },
    {
      "code" : "TP-21-08",
      "display" : "全部修復（前装金属冠・黒色）（前装ＭＣ）"
    },
    {
      "code" : "TP-21-09",
      "display" : "全部修復（前装金属冠・金色）（前装ＭＣ）"
    },
    {
      "code" : "TP-21-10",
      "display" : "全部修復（メタルボンドクラウン・銀色）（ＭＢ）"
    },
    {
      "code" : "TP-21-11",
      "display" : "全部修復（メタルボンドクラウン・黒色）（ＭＢ）"
    },
    {
      "code" : "TP-21-12",
      "display" : "全部修復（メタルボンドクラウン・金色）（ＭＢ）"
    },
    {
      "code" : "TP-21-13",
      "display" : "全部修復（コーヌス外冠・全部金属冠・銀色）"
    },
    {
      "code" : "TP-21-14",
      "display" : "全部修復（コーヌス外冠・全部金属冠・黒色）"
    },
    {
      "code" : "TP-21-15",
      "display" : "全部修復（コーヌス外冠・全部金属冠・金色）"
    },
    {
      "code" : "TP-21-16",
      "display" : "全部修復（コーヌス外冠・硬質レジン前装金属冠・銀色）"
    },
    {
      "code" : "TP-21-17",
      "display" : "全部修復（コーヌス外冠・硬質レジン前装金属冠・黒色）"
    },
    {
      "code" : "TP-21-18",
      "display" : "全部修復（コーヌス外冠・硬質レジン前装金属冠・金色）"
    },
    {
      "code" : "TP-21-19",
      "display" : "全部修復（コーヌス外冠・メタルボンドクラウン・銀色）"
    },
    {
      "code" : "TP-21-20",
      "display" : "全部修復（コーヌス外冠・メタルボンドクラウン・黒色）"
    },
    {
      "code" : "TP-21-21",
      "display" : "全部修復（コーヌス外冠・メタルボンドクラウン・金色）"
    },
    {
      "code" : "TP-21-22",
      "display" : "全部修復（帯環金属冠・種類不明・銀色）"
    },
    {
      "code" : "TP-21-23",
      "display" : "全部修復（帯環金属冠・種類不明・黒色）"
    },
    {
      "code" : "TP-21-24",
      "display" : "全部修復（帯環金属冠・種類不明・金色）"
    },
    {
      "code" : "TP-21-25",
      "display" : "全部修復（帯環金属冠・嚼面圧印冠・銀色）"
    },
    {
      "code" : "TP-21-26",
      "display" : "全部修復（帯環金属冠・嚼面圧印冠・黒色）"
    },
    {
      "code" : "TP-21-27",
      "display" : "全部修復（帯環金属冠・嚼面圧印冠・金色）"
    },
    {
      "code" : "TP-21-28",
      "display" : "全部修復（帯環金属冠・嚼面充実冠・銀色）（ＰＫ）"
    },
    {
      "code" : "TP-21-29",
      "display" : "全部修復（帯環金属冠・嚼面充実冠・黒色）（ＰＫ）"
    },
    {
      "code" : "TP-21-30",
      "display" : "全部修復（帯環金属冠・嚼面充実冠・金色）（ＰＫ）"
    },
    {
      "code" : "TP-21-31",
      "display" : "全部修復（帯環金属冠・嚼面鋳造冠・銀色）（ＣＣＫ）"
    },
    {
      "code" : "TP-21-32",
      "display" : "全部修復（帯環金属冠・嚼面鋳造冠・黒色）（ＣＣＫ）"
    },
    {
      "code" : "TP-21-33",
      "display" : "全部修復（帯環金属冠・嚼面鋳造冠・金色）（ＣＣＫ）"
    },
    {
      "code" : "TP-21-34",
      "display" : "全部修復（帯環金属冠・開面金冠・銀色）"
    },
    {
      "code" : "TP-21-35",
      "display" : "全部修復（帯環金属冠・開面金冠・黒色）"
    },
    {
      "code" : "TP-21-36",
      "display" : "全部修復（帯環金属冠・開面金冠・金色）"
    },
    {
      "code" : "TP-21-37",
      "display" : "全部修復（歯冠継続歯・レジン前装継続歯・銀色）（ＰＣ）"
    },
    {
      "code" : "TP-21-38",
      "display" : "全部修復（歯冠継続歯・レジン前装継続歯・黒色）（ＰＣ）"
    },
    {
      "code" : "TP-21-39",
      "display" : "全部修復（歯冠継続歯・レジン前装継続歯・金色）（ＰＣ）"
    },
    {
      "code" : "TP-21-40",
      "display" : "全部修復（歯冠継続歯・全部レジン冠継続歯・歯冠色）（ＰＣ）"
    },
    {
      "code" : "TP-21-41",
      "display" : "全部修復（乳歯冠・乳歯金属冠・銀色）"
    },
    {
      "code" : "TP-21-42",
      "display" : "全部修復（乳歯冠・乳歯ジャケット冠・複合レジン冠・歯冠色）"
    },
    {
      "code" : "TP-21-43",
      "display" : "全部修復（小児保隙装置・銀色）"
    },
    {
      "code" : "TP-21-44",
      "display" : "全部修復（既製金属冠・永久歯金属冠・銀色）"
    },
    {
      "code" : "TP-22-01",
      "display" : "根面板（金属・銀色）"
    },
    {
      "code" : "TP-22-02",
      "display" : "根面板（金属・黒色）"
    },
    {
      "code" : "TP-22-03",
      "display" : "根面板（金属・金色）"
    },
    {
      "code" : "TP-22-04",
      "display" : "根面板（非金属・レジン系（様）・歯冠色他）"
    },
    {
      "code" : "TP-22-05",
      "display" : "根面板（非金属・セラミック系（様）・歯冠色他）"
    },
    {
      "code" : "TP-22-06",
      "display" : "根面板（非金属・材質不明、又は材質記載なし・歯冠色他）"
    },
    {
      "code" : "TP-22-07",
      "display" : "コーヌス内冠（金属冠・銀色）"
    },
    {
      "code" : "TP-22-08",
      "display" : "コーヌス内冠（金属冠・黒色）"
    },
    {
      "code" : "TP-22-09",
      "display" : "コーヌス内冠（金属冠・金色）"
    },
    {
      "code" : "TP-22-10",
      "display" : "アバットメント（インプラント）"
    },
    {
      "code" : "TP-22-11",
      "display" : "アタッチメント（磁性、キーパー付き根面板含む）（アバットメントの場合含む）"
    },
    {
      "code" : "TP-22-12",
      "display" : "アタッチメント（バー支台）（アバットメントの場合含む）"
    },
    {
      "code" : "TP-22-13",
      "display" : "アタッチメント(その他）（アバットメントの場合含む）"
    },
    {
      "code" : "TP-23-01",
      "display" : "連結冠（インプラント含む）"
    },
    {
      "code" : "TP-23-02",
      "display" : "ブリッジ支台歯（インプラント含む）"
    },
    {
      "code" : "TP-23-03",
      "display" : "隙の支台歯（インプラント含む）"
    },
    {
      "code" : "TP-24-01",
      "display" : "同顎１装置目（固定性）"
    },
    {
      "code" : "TP-24-02",
      "display" : "同顎２装置目（固定性）"
    },
    {
      "code" : "TP-24-03",
      "display" : "同顎３装置目（固定性）"
    },
    {
      "code" : "TP-24-04",
      "display" : "同顎４装置目（固定性）"
    },
    {
      "code" : "TP-24-05",
      "display" : "同顎５装置目（固定性）"
    },
    {
      "code" : "TP-24-06",
      "display" : "同顎６装置目（固定性）"
    },
    {
      "code" : "TP-24-07",
      "display" : "同顎７装置目（固定性）"
    },
    {
      "code" : "TP-24-08",
      "display" : "同顎８装置目（固定性）"
    },
    {
      "code" : "TP-24-09",
      "display" : "同顎１装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-10",
      "display" : "同顎２装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-11",
      "display" : "同顎３装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-12",
      "display" : "同顎４装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-13",
      "display" : "同顎５装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-14",
      "display" : "同顎６装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-15",
      "display" : "同顎７装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-24-16",
      "display" : "同顎８装置目（半固定性・可撤性）"
    },
    {
      "code" : "TP-25-01",
      "display" : "レストシート等あり"
    },
    {
      "code" : "TP-26-01",
      "display" : "鉤（内容不明）"
    },
    {
      "code" : "TP-26-02",
      "display" : "鋳造鉤（双子鉤・銀色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-03",
      "display" : "鋳造鉤（双子鉤・黒色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-04",
      "display" : "鋳造鉤（双子鉤・金色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-05",
      "display" : "鋳造鉤（二腕鉤・レスト付き・銀色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-06",
      "display" : "鋳造鉤（二腕鉤・レスト付き・黒色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-07",
      "display" : "鋳造鉤（二腕鉤・レスト付き・金色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-08",
      "display" : "線鉤（双子鉤・銀色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-09",
      "display" : "線鉤（双子鉤・黒色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-10",
      "display" : "線鉤（双子鉤・金色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-11",
      "display" : "線鉤（二腕鉤・レスト付き・銀色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-12",
      "display" : "線鉤（二腕鉤・レスト付き・黒色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-13",
      "display" : "線鉤（二腕鉤・レスト付き・金色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-14",
      "display" : "線鉤（レストのないもの・銀色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-15",
      "display" : "線鉤（レストのないもの・黒色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-16",
      "display" : "線鉤（レストのないもの・金色）（Ｃｌ）"
    },
    {
      "code" : "TP-26-17",
      "display" : "コンビネーション鉤（二腕鉤・銀色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-18",
      "display" : "コンビネーション鉤（二腕鉤・黒色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-19",
      "display" : "コンビネーション鉤（二腕鉤・金色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-20",
      "display" : "コンビネーション鉤（双子鉤・銀色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-21",
      "display" : "コンビネーション鉤（双子鉤・黒色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-22",
      "display" : "コンビネーション鉤（双子鉤・金色）（コンビＣｌ）"
    },
    {
      "code" : "TP-26-23",
      "display" : "非金属鉤（歯冠色）"
    },
    {
      "code" : "TP-26-24",
      "display" : "非金属鉤（歯肉色）"
    },
    {
      "code" : "TP-26-25",
      "display" : "フック（銀色）"
    },
    {
      "code" : "TP-26-26",
      "display" : "フック（黒色）"
    },
    {
      "code" : "TP-26-27",
      "display" : "フック（金色）"
    },
    {
      "code" : "TP-26-28",
      "display" : "スパー（銀色）"
    },
    {
      "code" : "TP-26-29",
      "display" : "スパー（黒色）"
    },
    {
      "code" : "TP-26-30",
      "display" : "スパー（金色）"
    },
    {
      "code" : "TP-26-31",
      "display" : "間接支台装置（レスト、フック、スパー又は線鉤（単純鉤））（銀色）"
    },
    {
      "code" : "TP-26-32",
      "display" : "間接支台装置（レスト、フック、スパー又は線鉤（単純鉤））（黒色）"
    },
    {
      "code" : "TP-26-33",
      "display" : "間接支台装置（レスト、フック、スパー又は線鉤（単純鉤））（金色）"
    },
    {
      "code" : "TP-26-34",
      "display" : "アダムスクラスプ"
    },
    {
      "code" : "TP-26-35",
      "display" : "矯正用クラスプ"
    },
    {
      "code" : "TP-27-01",
      "display" : "ダイレクトボンドブラケット（唇側・金属）"
    },
    {
      "code" : "TP-27-02",
      "display" : "ダイレクトボンドブラケット（唇側・非金属）"
    },
    {
      "code" : "TP-27-03",
      "display" : "ダイレクトボンドブラケット（舌側・金属）"
    },
    {
      "code" : "TP-27-04",
      "display" : "ダイレクトボンドブラケット（舌側・非金属）"
    },
    {
      "code" : "TP-27-05",
      "display" : "帯環"
    },
    {
      "code" : "TP-27-06",
      "display" : "フィクスドリテーナー"
    },
    {
      "code" : "TP-27-07",
      "display" : "牽引装置"
    },
    {
      "code" : "TP-28-01",
      "display" : "暫間固定（ＴＦｉｘ）"
    },
    {
      "code" : "TP-28-02",
      "display" : "線副子"
    },
    {
      "code" : "TP-29-01",
      "display" : "歯肉退縮"
    },
    {
      "code" : "TP-29-02",
      "display" : "歯肉増殖"
    },
    {
      "code" : "TP-29-03",
      "display" : "歯肉色素沈着"
    },
    {
      "code" : "TP-30-01",
      "display" : "歯石沈着（ＺＳ）"
    },
    {
      "code" : "TP-31-01",
      "display" : "歯根のう胞（ＷＺ）"
    },
    {
      "code" : "TP-32-01",
      "display" : "ろう孔（内歯瘻）"
    },
    {
      "code" : "TP-32-02",
      "display" : "ろう孔（外歯瘻）"
    },
    {
      "code" : "TP-33-01",
      "display" : "骨瘤（唇側・頬側）（Ｔｏｒ）"
    },
    {
      "code" : "TP-33-02",
      "display" : "骨瘤（舌側・口蓋側）（Ｔｏｒ）"
    },
    {
      "code" : "TP-33-03",
      "display" : "骨瘤（唇側・頬側および舌側・口蓋側）（Ｔｏｒ）"
    },
    {
      "code" : "TP-33-04",
      "display" : "骨瘤（側不明）（Ｔｏｒ）"
    }
  ]
}

```
