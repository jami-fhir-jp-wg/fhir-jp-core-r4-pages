# FHIR Contents List - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev-temp

* [**Table of Contents**](toc.md)
* **FHIR Contents List**

## FHIR Contents List

* [Administrationグループ](group-administration.md)
* [Medicationグループ](group-medication.md)
* [Diagnosticグループ](group-diagnostic.md)
* [Clinicalグループ](group-clinical.md)
* [Security and Privacyグループ](group-security-and-privacy.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。