# JP Core Observation Electrocardiogram Extra Category CodeSystem - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev-temp

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Observation Electrocardiogram Extra Category CodeSystem**

## CodeSystem: JP Core Observation Electrocardiogram Extra Category CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_ObservationElectrocardiogramExtraCategory_CS
* **項目**: *Version*
  * **内容**: 2.0.0-dev-temp
* **項目**: *Name*
  * **内容**: JP_ObservationElectrocardiogramExtraCategory_CS
* **項目**: *Title*
  * **内容**: JP Core Observation Electrocardiogram Extra Category CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2024-12-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義した心電図のObservationリソースに関する分類コード 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_ObservationElectrocardiogramExtraCategory_VS](ValueSet-jp-observation-electrocardiogram-extracategory-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-observation-electrocardiogram-extracategory-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_ObservationElectrocardiogramExtraCategory_CS",
  "version" : "2.0.0-dev-temp",
  "name" : "JP_ObservationElectrocardiogramExtraCategory_CS",
  "title" : "JP Core Observation Electrocardiogram Extra Category CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義した心電図のObservationリソースに関する分類コード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 12,
  "concept" : [
    {
      "code" : "JECGCAT0100",
      "display" : "安静時心電図"
    },
    {
      "code" : "JECGCAT0200",
      "display" : "マスター負荷心電図"
    },
    {
      "code" : "JECGCAT0300",
      "display" : "負荷心電図"
    },
    {
      "code" : "JECGCAT0400",
      "display" : "不整脈心電図"
    },
    {
      "code" : "JECGCAT0500",
      "display" : "心拍数変動（R-R間隔）"
    },
    {
      "code" : "JECGCAT0600",
      "display" : "ホルター心電図"
    },
    {
      "code" : "JECGCAT0700",
      "display" : "ストレス心電図"
    },
    {
      "code" : "JECGCAT0800",
      "display" : "イベントレコーダー"
    },
    {
      "code" : "JECGCAT0900",
      "display" : "レートポテンシャル（LP）"
    },
    {
      "code" : "JECGCAT1000",
      "display" : "学童心電図"
    },
    {
      "code" : "JECGCAT1100",
      "display" : "ベクトル心電図"
    },
    {
      "code" : "JECGCAT1200",
      "display" : "体表HIS束心電図"
    }
  ]
}

```
