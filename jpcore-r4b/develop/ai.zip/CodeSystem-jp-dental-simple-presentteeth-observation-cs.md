# JP Core Dental SimplePresentTeethObservation CodeSystem - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev-temp

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Dental SimplePresentTeethObservation CodeSystem**

## CodeSystem: JP Core Dental SimplePresentTeethObservation CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalSimplePresentTeethObservation_CS
* **項目**: *Version*
  * **内容**: 2.0.0-dev-temp
* **項目**: *Name*
  * **内容**: JP_DentalSipmlePresentTeethObservation_CS
* **項目**: *Title*
  * **内容**: JP Core Dental SimplePresentTeethObservation CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2025-07-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義した歯科のObservationリソースに関する現存歯の観察結果コード（簡易版） 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_DentalSimplePresentTeethObservation_VS](ValueSet-jp-dental-simple-presentteeth-observation-vs.md)
* [JP_DentalTeethObservation_VS](ValueSet-jp-dental-teethobservation-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-dental-simple-presentteeth-observation-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalSimplePresentTeethObservation_CS",
  "version" : "2.0.0-dev-temp",
  "name" : "JP_DentalSipmlePresentTeethObservation_CS",
  "title" : "JP Core Dental SimplePresentTeethObservation CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-07-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義した歯科のObservationリソースに関する現存歯の観察結果コード（簡易版）",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 21,
  "concept" : [
    {
      "code" : "TD-2-01",
      "display" : "現在歯【現在歯／】（残存歯）（状態不明）（レセプト表記略称名がＧ又はＰの場合）"
    },
    {
      "code" : "TD-2-02",
      "display" : "現在歯【健全歯／】（治療痕なし）"
    },
    {
      "code" : "TD-2-03",
      "display" : "現在歯【健全歯（シーラント：シ）】"
    },
    {
      "code" : "TD-2-04",
      "display" : "現在歯【要観察歯ＣＯ】"
    },
    {
      "code" : "TD-2-05",
      "display" : "現在歯【要観察歯（サホライド：サ）】"
    },
    {
      "code" : "TD-2-06",
      "display" : "現在歯【未処置歯Ｃ】（治療中を含む）"
    },
    {
      "code" : "TD-2-07",
      "display" : "現在歯【未処置歯（サホライド：サ）】"
    },
    {
      "code" : "TD-2-08",
      "display" : "現在歯（残根上義歯）残根、Ｃ４（未処置歯）"
    },
    {
      "code" : "TD-2-09",
      "display" : "現在歯（残根上義歯）根面板等（処置歯）"
    },
    {
      "code" : "TD-2-10",
      "display" : "現在歯【処置歯○】（ブリッジＢｒ支台を含む）"
    },
    {
      "code" : "TD-2-11",
      "display" : "現在歯【要注意乳歯×】"
    },
    {
      "code" : "TD-2-12",
      "display" : "現在歯【現在歯／】（上記以外、何か情報あり）"
    },
    {
      "code" : "TD-2-13",
      "display" : "現在歯（死後脱落（歯槽窩あり））、又は（死後脱落の疑い（歯槽窩あり））"
    },
    {
      "code" : "TD-2-30",
      "display" : "半埋伏歯（ＨＲＴ）"
    },
    {
      "code" : "TD-2-31",
      "display" : "半埋伏歯（ＨＲＴ）（水平）"
    },
    {
      "code" : "TD-2-32",
      "display" : "埋伏歯（ＲＴ）（詳細不明）"
    },
    {
      "code" : "TD-2-33",
      "display" : "埋伏歯（ＲＴ）（水平）"
    },
    {
      "code" : "TD-2-34",
      "display" : "埋伏歯（完全）（ＣＲＴ）"
    },
    {
      "code" : "TD-2-35",
      "display" : "水平埋伏智歯（ＨＩＴ）"
    },
    {
      "code" : "TD-2-36",
      "display" : "未萌出歯"
    },
    {
      "code" : "TD-2-37",
      "display" : "萌出途中"
    }
  ]
}

```
