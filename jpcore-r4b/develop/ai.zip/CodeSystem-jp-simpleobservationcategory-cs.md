# JP Core Simple Observation Category CodeSystem - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev-temp

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Simple Observation Category CodeSystem**

## CodeSystem: JP Core Simple Observation Category CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS
* **項目**: *Version*
  * **内容**: 2.0.0-dev-temp
* **項目**: *Name*
  * **内容**: JP_SimpleObservationCategory_CS
* **項目**: *Title*
  * **内容**: JP Core Simple Observation Category CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2023-10-31 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義したObservationリソースに関する分類コード 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_SimpleObservationCategory_VS](ValueSet-jp-simpleobservationcategory-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-simpleobservationcategory-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
  "version" : "2.0.0-dev-temp",
  "name" : "JP_SimpleObservationCategory_CS",
  "title" : "JP Core Simple Observation Category CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-10-31",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義したObservationリソースに関する分類コード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 14,
  "concept" : [
    {
      "code" : "sdoh",
      "display" : "SDOH",
      "definition" : "健康の社会的決定要因 (Social Determinant of Health)"
    },
    {
      "code" : "functional-status",
      "display" : "Functional Status",
      "definition" : "機能ステータス"
    },
    {
      "code" : "disability-status",
      "display" : "Disability Status",
      "definition" : "障害区分"
    },
    {
      "code" : "cognitive-status",
      "display" : "Cognitive Status",
      "definition" : "認知ステータスのカテゴリ"
    },
    {
      "code" : "social-history",
      "display" : "Social History",
      "definition" : "社会歴観察では、患者の職業、個人（ライフスタイルなど）、社会歴、家族歴、環境歴、および患者の健康に影響を与える可能性のある健康リスク要因を定義。"
    },
    {
      "code" : "vital-signs",
      "display" : "Vital Signs",
      "definition" : "身体の基本機能のうち、呼吸機能、不整脈、血圧、体表面皮膚温、睡眠、意識障害、体温、脈拍数など。"
    },
    {
      "code" : "body-measurement",
      "display" : "Body Measurement",
      "definition" : "身体の基本機能のうち、体重、身長、胸囲、腹囲、嚥下、握力など。"
    },
    {
      "code" : "imaging",
      "display" : "Imaging",
      "definition" : "イメージングによって生成された観測。 範囲には、単純X線、超音波、CT、MRI、血管造影、心エコー検査、および核医学に関する観察が含まれる。"
    },
    {
      "code" : "laboratory",
      "display" : "Laboratory",
      "definition" : "検査室によって生成された観察結果。 検査結果は通常、化学、血液学、血清学、組織学、細胞学、解剖病理学 (デジタル病理学を含む)、微生物学、および/またはウイルス学などの分野で分析サービスを提供する検査室によって生成される。 これらの観察結果は、患者から採取され、検査室に提出された検体の分析に基づいている。"
    },
    {
      "code" : "procedure",
      "display" : "Procedure",
      "definition" : "他の手順によって生成された観察。 このカテゴリには、実験室および画像検査 (心臓カテーテル法、内視鏡検査、電気診断など) を除く、介入および非介入手順から生じる観察結果が含まれる。 通常、検査結果は臨床医によって生成され、検査中に行われたコンポーネントの観察に関するより詳細な情報を提供する。 例としては、消化器内科医が大腸内視鏡検査中に観察されたポリープのサイズを報告する場合がある。"
    },
    {
      "code" : "survey",
      "display" : "Survey",
      "definition" : "評価ツール/調査機器の観察 (例: Apgar Scores、Montreal Cognitive Assessment (MoCA))。"
    },
    {
      "code" : "exam",
      "display" : "Exam",
      "definition" : "臨床医による直接観察、単純な器具の使用、患者の体に直接行われた単純な操作の結果など、身体検査の結果によって生成された観察。"
    },
    {
      "code" : "therapy",
      "display" : "Therapy",
      "definition" : "非介入治療プロトコル（例：職業療法、物理療法、放射線療法、栄養療法、投薬療法）によって生成された観察"
    },
    {
      "code" : "activity",
      "display" : "Activity",
      "definition" : "体力と全体的な健康状態を向上または維持する身体活動を測定または記録する観察。 理学療法士などの施術者の直接の監督下にないこと。 (例: 水泳ラップ、歩数、睡眠データ)"
    }
  ]
}

```
