# JP Core Dental BodySite CodeSystem - HL7 FHIR JP Core ImplementationGuide v2.0.0-dev-temp

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Dental BodySite CodeSystem**

## CodeSystem: JP Core Dental BodySite CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalBodySite_CS
* **項目**: *Version*
  * **内容**: 2.0.0-dev-temp
* **項目**: *Name*
  * **内容**: JP_DentalBodySite_CS
* **項目**: *Title*
  * **内容**: JP Core Dental BodySite CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2025-07-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義した歯科のObservationリソースに関する身体部位コード 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_DentalBodySite_VS](ValueSet-jp-dental-bodysite-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-dental-bodysite-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalBodySite_CS",
  "version" : "2.0.0-dev-temp",
  "name" : "JP_DentalBodySite_CS",
  "title" : "JP Core Dental BodySite CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-07-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義した歯科のObservationリソースに関する身体部位コード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 104,
  "concept" : [
    {
      "code" : "1011",
      "display" : "右側上顎中切歯"
    },
    {
      "code" : "1012",
      "display" : "右側上顎側切歯"
    },
    {
      "code" : "1013",
      "display" : "右側上顎犬歯"
    },
    {
      "code" : "1014",
      "display" : "右側上顎第１小臼歯"
    },
    {
      "code" : "1015",
      "display" : "右側上顎第２小臼歯"
    },
    {
      "code" : "1016",
      "display" : "右側上顎第１大臼歯"
    },
    {
      "code" : "1017",
      "display" : "右側上顎第２大臼歯"
    },
    {
      "code" : "1018",
      "display" : "右側上顎第３大臼歯"
    },
    {
      "code" : "1021",
      "display" : "左側上顎中切歯"
    },
    {
      "code" : "1022",
      "display" : "左側上顎側切歯"
    },
    {
      "code" : "1023",
      "display" : "左側上顎犬歯"
    },
    {
      "code" : "1024",
      "display" : "左側上顎第１小臼歯"
    },
    {
      "code" : "1025",
      "display" : "左側上顎第２小臼歯"
    },
    {
      "code" : "1026",
      "display" : "左側上顎第１大臼歯"
    },
    {
      "code" : "1027",
      "display" : "左側上顎第２大臼歯"
    },
    {
      "code" : "1028",
      "display" : "左側上顎第３大臼歯"
    },
    {
      "code" : "1031",
      "display" : "左側下顎中切歯"
    },
    {
      "code" : "1032",
      "display" : "左側下顎側切歯"
    },
    {
      "code" : "1033",
      "display" : "左側下顎犬歯"
    },
    {
      "code" : "1034",
      "display" : "左側下顎第１小臼歯"
    },
    {
      "code" : "1035",
      "display" : "左側下顎第２小臼歯"
    },
    {
      "code" : "1036",
      "display" : "左側下顎第１大臼歯"
    },
    {
      "code" : "1037",
      "display" : "左側下顎第２大臼歯"
    },
    {
      "code" : "1038",
      "display" : "左側下顎第３大臼歯"
    },
    {
      "code" : "1041",
      "display" : "右側下顎中切歯"
    },
    {
      "code" : "1042",
      "display" : "右側下顎側切歯"
    },
    {
      "code" : "1043",
      "display" : "右側下顎犬歯"
    },
    {
      "code" : "1044",
      "display" : "右側下顎第１小臼歯"
    },
    {
      "code" : "1045",
      "display" : "右側下顎第２小臼歯"
    },
    {
      "code" : "1046",
      "display" : "右側下顎第１大臼歯"
    },
    {
      "code" : "1047",
      "display" : "右側下顎第２大臼歯"
    },
    {
      "code" : "1048",
      "display" : "右側下顎第３大臼歯"
    },
    {
      "code" : "1051",
      "display" : "右側上顎乳中切歯"
    },
    {
      "code" : "1052",
      "display" : "右側上顎乳側切歯"
    },
    {
      "code" : "1053",
      "display" : "右側上顎乳犬歯"
    },
    {
      "code" : "1054",
      "display" : "右側上顎第１乳臼歯"
    },
    {
      "code" : "1055",
      "display" : "右側上顎第２乳臼歯"
    },
    {
      "code" : "1061",
      "display" : "左側上顎乳中切歯"
    },
    {
      "code" : "1062",
      "display" : "左側上顎乳側切歯"
    },
    {
      "code" : "1063",
      "display" : "左側上顎乳犬歯"
    },
    {
      "code" : "1064",
      "display" : "左側上顎第１乳臼歯"
    },
    {
      "code" : "1065",
      "display" : "左側上顎第２乳臼歯"
    },
    {
      "code" : "1071",
      "display" : "左側下顎乳中切歯"
    },
    {
      "code" : "1072",
      "display" : "左側下顎乳側切歯"
    },
    {
      "code" : "1073",
      "display" : "左側下顎乳犬歯"
    },
    {
      "code" : "1074",
      "display" : "左側下顎第１乳臼歯"
    },
    {
      "code" : "1075",
      "display" : "左側下顎第２乳臼歯"
    },
    {
      "code" : "1081",
      "display" : "右側下顎乳中切歯"
    },
    {
      "code" : "1082",
      "display" : "右側下顎乳側切歯"
    },
    {
      "code" : "1083",
      "display" : "右側下顎乳犬歯"
    },
    {
      "code" : "1084",
      "display" : "右側下顎第１乳臼歯"
    },
    {
      "code" : "1085",
      "display" : "右側下顎第２乳臼歯"
    },
    {
      "code" : "101A",
      "display" : "右側上顎中切歯近傍過剰歯"
    },
    {
      "code" : "101B",
      "display" : "右側上顎側切歯近傍過剰歯"
    },
    {
      "code" : "101C",
      "display" : "右側上顎犬歯近傍過剰歯"
    },
    {
      "code" : "101D",
      "display" : "右側上顎第１小臼歯近傍過剰歯"
    },
    {
      "code" : "101E",
      "display" : "右側上顎第２小臼歯近傍過剰歯"
    },
    {
      "code" : "101F",
      "display" : "右側上顎第１大臼歯近傍過剰歯"
    },
    {
      "code" : "101G",
      "display" : "右側上顎第２大臼歯近傍過剰歯"
    },
    {
      "code" : "101H",
      "display" : "右側上顎第３大臼歯近傍過剰歯"
    },
    {
      "code" : "102A",
      "display" : "左側上顎中切歯近傍過剰歯"
    },
    {
      "code" : "102B",
      "display" : "左側上顎側切歯近傍過剰歯"
    },
    {
      "code" : "102C",
      "display" : "左側上顎犬歯近傍過剰歯"
    },
    {
      "code" : "102D",
      "display" : "左側上顎第１小臼歯近傍過剰歯"
    },
    {
      "code" : "102E",
      "display" : "左側上顎第２小臼歯近傍過剰歯"
    },
    {
      "code" : "102F",
      "display" : "左側上顎第１大臼歯近傍過剰歯"
    },
    {
      "code" : "102G",
      "display" : "左側上顎第２大臼歯近傍過剰歯"
    },
    {
      "code" : "102H",
      "display" : "左側上顎第３大臼歯近傍過剰歯"
    },
    {
      "code" : "103A",
      "display" : "左側下顎中切歯近傍過剰歯"
    },
    {
      "code" : "103B",
      "display" : "左側下顎側切歯近傍過剰歯"
    },
    {
      "code" : "103C",
      "display" : "左側下顎犬歯近傍過剰歯"
    },
    {
      "code" : "103D",
      "display" : "左側下顎第１小臼歯近傍過剰歯"
    },
    {
      "code" : "103E",
      "display" : "左側下顎第２小臼歯近傍過剰歯"
    },
    {
      "code" : "103F",
      "display" : "左側下顎第１大臼歯近傍過剰歯"
    },
    {
      "code" : "103G",
      "display" : "左側下顎第２大臼歯近傍過剰歯"
    },
    {
      "code" : "103H",
      "display" : "左側下顎第３大臼歯近傍過剰歯"
    },
    {
      "code" : "104A",
      "display" : "右側下顎中切歯近傍過剰歯"
    },
    {
      "code" : "104B",
      "display" : "右側下顎側切歯近傍過剰歯"
    },
    {
      "code" : "104C",
      "display" : "右側下顎犬歯近傍過剰歯"
    },
    {
      "code" : "104D",
      "display" : "右側下顎第１小臼歯近傍過剰歯"
    },
    {
      "code" : "104E",
      "display" : "右側下顎第２小臼歯近傍過剰歯"
    },
    {
      "code" : "104F",
      "display" : "右側下顎第１大臼歯近傍過剰歯"
    },
    {
      "code" : "104G",
      "display" : "右側下顎第２大臼歯近傍過剰歯"
    },
    {
      "code" : "104H",
      "display" : "右側下顎第３大臼歯近傍過剰歯"
    },
    {
      "code" : "105A",
      "display" : "右側上顎乳中切歯近傍過剰歯"
    },
    {
      "code" : "105B",
      "display" : "右側上顎乳側切歯近傍過剰歯"
    },
    {
      "code" : "105C",
      "display" : "右側上顎乳犬歯近傍過剰歯"
    },
    {
      "code" : "105D",
      "display" : "右側上顎第１乳臼歯近傍過剰歯"
    },
    {
      "code" : "105E",
      "display" : "右側上顎第２乳臼歯近傍過剰歯"
    },
    {
      "code" : "106A",
      "display" : "左側上顎乳中切歯近傍過剰歯"
    },
    {
      "code" : "106B",
      "display" : "左側上顎乳側切歯近傍過剰歯"
    },
    {
      "code" : "106C",
      "display" : "左側上顎乳犬歯近傍過剰歯"
    },
    {
      "code" : "106D",
      "display" : "左側上顎第１乳臼歯近傍過剰歯"
    },
    {
      "code" : "106E",
      "display" : "左側上顎第２乳臼歯近傍過剰歯"
    },
    {
      "code" : "107A",
      "display" : "左側下顎乳中切歯近傍過剰歯"
    },
    {
      "code" : "107B",
      "display" : "左側下顎乳側切歯近傍過剰歯"
    },
    {
      "code" : "107C",
      "display" : "左側下顎乳犬歯近傍過剰歯"
    },
    {
      "code" : "107D",
      "display" : "左側下顎第１乳臼歯近傍過剰歯"
    },
    {
      "code" : "107E",
      "display" : "左側下顎第２乳臼歯近傍過剰歯"
    },
    {
      "code" : "108A",
      "display" : "右側下顎乳中切歯近傍過剰歯"
    },
    {
      "code" : "108B",
      "display" : "右側下顎乳側切歯近傍過剰歯"
    },
    {
      "code" : "108C",
      "display" : "右側下顎乳犬歯近傍過剰歯"
    },
    {
      "code" : "108D",
      "display" : "右側下顎第１乳臼歯近傍過剰歯"
    },
    {
      "code" : "108E",
      "display" : "右側下顎第２乳臼歯近傍過剰歯"
    }
  ]
}

```
