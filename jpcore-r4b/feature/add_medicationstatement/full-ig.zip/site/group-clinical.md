### Profiles
* [JP Core AllergyIntolerance （アレルギー不耐症）プロファイル][JP_AllergyIntolerance]
* [JP Core Condition （状態）プロファイル][JP_Condition]
* [JP Core Procedure （処置）プロファイル][JP_Procedure]
* [JP Core FamilyMemberHistory（家族歴）プロファイル][JP_FamilyMemberHistory]
* [JP Core CarePlan（ケアプラン）プロファイル][JP_CarePlan]

### Extensions
なし


{% include markdown-link-references.md %}